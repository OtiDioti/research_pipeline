## Milestone 1, attempt 0, integration 0
Found two actionable defects:

1. **[P1] Resume republishes already settled job drafts.** In [jobs.py:216](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/jobs.py:216), forced reconciliation resets terminal jobs to running and subsequently calls `publish()` again. A previously published Markdown output then compares against its original baseline, which predates publication. This creates false human-edit conflicts—even when canonical content is unchanged—and replaces prior publication/supersession metadata. Those unresolved conflicts prevent subsequent scientific finalization. Keep ownership/outcome reconciliation independent of publication, preserving settled publication records. Add a STOP/resume regression with an already published job output and verify that no conflicts appear and subsequent finalization remains possible.

2. **[P2] Cancellation can misreport an independently enforced timeout.** In [jobs.py:345](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/jobs.py:345), cancellation recognizes expiry only through the supervisor result. If the original systemd deadline expires after the initial reconciliation and kills the supervisor before it writes a final result, `stop_owned()` can return confirmed cleanup with `properties.Result == 'timeout'`, but this branch records `cancelled`. Incorporate the observed service timeout into outcome classification, as `_reconcile()` already does. Add a cancellation-race test with timeout service properties and no final supervisor result.

I read the complete diff and supporting artifacts. Tests were not executed, as requested. The documented deferrals fit this milestone’s plan; these defects affect its delivered resume behavior.

CWI: changes_requested

## Milestone 1, attempt 1, integration 0
One defect remains:

**[P2] Resume loses a previously observed timeout when the supervisor left no final result.** In [jobs.py:216](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/jobs.py:216), forced reconciliation replaces the saved terminal state with `running`. After the newly tested cancellation race records `timed_out`, a later resume encounters the unfinished result and a collected service (`LoadState=not-found`). It then changes the outcome to `failed`, reports the command outcome unavailable, and overwrites the cleanup record containing the timeout evidence.

Preserve durable, previously observed outcomes while independently rechecking ownership and cleanup. Extend the new timeout-race regression through saved-state reconstruction and resume with the service absent; assert that `timed_out`, its supporting observation, original deadline, and partial outputs survive.

The settled-publication repair addresses the first finding. I read the complete revised diff and supporting evidence; I did not execute tests. Later L5 reopening, crash recovery, and native acceptance remain appropriately deferred for this milestone.

CWI: changes_requested

## Milestone 1, attempt 2, integration 0
**[P2] Unconfirmed cancellation is saved as an observed cancellation.** In [jobs.py:395](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/jobs.py:395), `cancel()` calls `remember_outcome()` even when cleanup is unconfirmed and no final supervisor result exists. For example, a foreign invocation can prevent any stop signal, yet the saved observation says `cancelled` with the explanation “Owned service stopped on cancellation.”

When a later reconciliation finds the service absent and no final result, it retains this observation and reports cancellation as the actual outcome. This converts a rejected cancellation request into a claimed result.

Only retain cancellation as observed when supported by confirmed termination or authoritative outcome evidence. Otherwise preserve the uncertainty and cancellation request separately. Add a regression starting without a prior outcome: reject cleanup, then reconcile an absent service with no final result and verify that cancellation is not claimed.

The previous publication and timeout-preservation findings are addressed. I read the complete current diff and supporting evidence; I did not run tests.

CWI: changes_requested

## Milestone 1, attempt 0, integration 0
**[P2] Timeout evidence can still be lost during cancellation.** At [jobs.py:380](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/jobs.py:380), timeout classification depends on the final properties returned by `stop_owned()`.

If reconciliation first observes an active job, then `stop_owned()` observes the owned service with `Result=timeout`, stopping/collecting that unit can leave its final properties as `LoadState=not-found`. `stop_owned()` discards the earlier timeout observation. Without a final supervisor result or prior outcome, `cancel()` consequently records `cancelled`; resume then preserves that incorrect outcome.

Preserve verified timeout observations across cleanup, separately from the final cleanup status. Add a regression using the real `stop_owned()` path with sequential active → owned timeout → absent observations and no final supervisor result. The current timeout regression mocks `stop_owned()` itself, hiding this loss.

I read the complete diff and supporting artifacts. No files were modified and no tests were executed.

CWI: changes_requested

## Milestone 1, attempt 1, integration 0
**[P2] An already-absent service is still recorded as observed cancellation.** At [jobs.py:387](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/jobs.py:387), `cleanup['confirmed']` alone authorizes `cancelled`.

If `_reconcile()` observes an active job, but the service disappears before `stop_owned()` observes it, an absent unit and empty cgroup produce confirmed cleanup without issuing any stop. With no final supervisor result or prior outcome, `cancel()` nevertheless saves an observed cancellation and claims “Owned service stopped on cancellation.” Restart then preserves this unsupported outcome.

Distinguish confirmed cleanup from an actual cancellation action. Preserve an unavailable command outcome when the service was already absent, while retaining the cancellation request. Add a regression using real `stop_owned()` with active → absent observations, an empty cgroup, and no final result; verify no stop command or observed cancellation.

The previous timeout-evidence finding is addressed. I read the complete updated diff and supporting evidence; no tests were executed or files modified.

CWI: changes_requested

## Milestone 2, attempt 0, integration 0
1. **[P1] Primary pause checkpoints always fail quota refresh.** At [collaboration.py:1532](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/collaboration.py:1532), the primary checkpoint calls `refresh_quota()`, which ends with `require_quota()`. That rejects the investigation’s already-latched pause admission block, even with sufficient fresh quota. Consequently, the primary never writes a fresh checkpoint and may lose recent progress or lack a resumable handoff. Apply the scoped checkpoint quota check after refresh while retaining the ordinary admission block. Add coverage with the primary configured as `quota_transport`; current checkpoint fixtures leave it unset.

2. **[P1] Quota STOP cannot interrupt an active pause checkpoint.** At [collaboration.py:1954](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/collaboration.py:1954), checkpoints run with `responsive=False`. If quota cutoff arrives during inference, `schedule_shutdown()` sets lifecycle events, but the checkpoint ignores them and the existing shutdown task waits for all checkpoints. Inference can therefore continue until completion or the 90-second timeout, violating quota STOP’s required interruption behavior. Give checkpoints a separate cutoff/failure cancellation signal and interrupt their transport when it fires. Test cutoff arriving after checkpoint inference starts; existing tests cover only cutoff before dispatch.

I read the complete supplied diff and supporting plan/evidence. No tests were executed. COMPLETE reopening is explicitly deferred by the milestone plan. Trusted production-process validation also remains unresolved: the enabled gate failed user-bus preflight, so reported discovery success does not establish M2 acceptance.

CWI: changes_requested

## Milestone 2, attempt 1, integration 0
1. **[P1] Historical preservation errors permanently poison resumed attempts.** [collaboration.py:434](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/collaboration.py:434) clears current runtime/task failures, but retains context/job error fields. Finalization subsequently checks every historical record for those errors. For example, a transient context `persistence_error` survives successful recovery and prevents every later pause or scientific terminal acknowledgement. Archive resolved diagnostics and distinguish them from outstanding preservation failures. Add a regression that resumes after a transient persistence failure and successfully finalizes the healthy attempt.

2. **[P2] Cached handoffs bypass integrity checks on linked immutable evidence.** [collaboration.py:269](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/collaboration.py:269) skips handoff validation when `validated_handoff` exists, checking only the context’s own documents and handoff hash. A handoff linking an immutable document from another context or job can therefore remain an accepted continuation basis after that document is corrupted or removed. Verify all linked immutable document IDs and recorded hashes before accepting cached handoffs. Cover corruption of a linked document outside the checkpoint’s `document_ids`.

Read the complete supplied diff, including repairs, and supporting records. No tests were executed. The earlier quota findings appear addressed. Trusted systemd/Bubblewrap validation remains pending because the enabled gate failed authorized user-bus preflight; COMPLETE reopening is explicitly deferred by the milestone plan.

CWI: changes_requested

## Milestone 3, attempt 0, integration 0
- **[P2] Preserve reopening context across a subsequent crash/resume** — [collaboration.py:437](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/collaboration.py:437). Reopening metadata is populated only for an acknowledged COMPLETE. After commit clears its markers and durably saves `phase='active'`, a crash before `reopening_note()` leaves no scientific handoff or status link describing the changes. The next resume archives that continuation and creates one without `reopening`; successor intake and `control(check/tasks)` consequently lose the changed-document versions and reassessment instructions. Newly added binary evidence is especially affected because `science_intake()` tracks Markdown only. Carry unresolved reopening metadata into subsequent recovery attempts until reassessment completes. Add a regression that crashes after the active save, before note publication, then resumes and verifies that the original changes remain exposed.

Read the complete diff and supporting artifacts. Reported verification passed 400 tests with nine gates skipped; I did not execute tests. Trusted native validation remains pending as documented.

CWI: changes_requested

## Milestone 4, attempt 0, integration 0
- **[P2] Verify continuity delivery to the resumed opponent** — [tests/test_v0_l5_native.py:406](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/tests/test_v0_l5_native.py:406). Intake assertions cover only the primary. The other checks establish that opponent identity, history and handoffs remain stored, but never verify that the fresh opponent receives its predecessor’s handoff and prior objections. The gate could therefore pass despite losing the opponent’s scientific continuity. Assert the resumed opponent’s intake handoff ID/hash and historical opposition metadata, and add a regression that rejects missing delivery.

Read the complete diff; no files modified or tests executed. Trusted native/process execution and final/combined verification remain pending, as documented.

CWI: changes_requested

## Milestone 5, attempt 0, integration 0
New or changed test failures; regressions or flakiness require repair. Comparison is conservative.

## Milestone 5, attempt 0, integration 1
New or changed test failures; regressions or flakiness require repair. Comparison is conservative.

## Milestone 5, attempt 0, integration 2
New or changed test failures; regressions or flakiness require repair. Comparison is conservative.

