Complete milestone diff: milestones/003/diffs/6adabf414590.diff
