<!-- cwi:decisions -->
Fixed reopening metadata loss across crash recovery and failed preflight. Original change versions and reassessment instructions persist; renewed COMPLETE establishes the next baseline. Trusted native validation remains pending.
<!-- /cwi:decisions -->
<!-- cwi:tests -->
Reproduced the defect before repair. Passed two focused tests, 186 affected tests, and full discovery: 401 tests with nine gates skipped. Compilation passed.
<!-- /cwi:tests -->
CWI: ready
