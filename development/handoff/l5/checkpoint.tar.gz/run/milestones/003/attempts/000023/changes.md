Complete milestone diff: milestones/003/diffs/e064eedbff4f.diff
