**Next milestone: L5-M3 — COMPLETE reopening and human direction**

Implement selective reopening through the existing owned resume transaction. An acknowledged, unchanged investigation reports its existing completion without admitting research. Relevant changes reopen the same investigation after successful preparation, preserving earlier science and requiring a new proposal and opponent assessment.

M1/M2 source approval does not establish trusted process or L5 acceptance. No source was modified or development command executed during this planning step.

**Discoveries affecting this milestone**

- `Coordinator.restore()` rejects COMPLETE, and `prepare_resume()` independently rejects its markers.
- `commit_resume()` removes only STOP markers and leaves `scientific_status='complete'`.
- Existing intake fingerprints cover starting evidence, optional instructions, feedback and reference authorization. `science_fingerprints()` covers Markdown, so it cannot alone detect changed scientific code, datasets or PDFs.
- Completion writes `RESEARCH_STATUS.md` and indexes after the last context baseline. A reopening baseline must account for those writes to avoid reopening unchanged investigations.
- `science_intake()`, `incorporate_edit`, immutable documents and publication guards already protect human corrections. Extend these mechanisms.
- Pause checkpoints reread human direction; rollover checkpoints currently use the earlier context prompt.
- Existing proposal invalidation and opponent reactivation already support renewed assessment by the same logical opponent.

**1. Record a completed investigation’s relevant versions**

Affected files: `src/research_pipeline/workspace.py`, `src/research_pipeline/collaboration.py`.

Add a small completion fingerprint helper, separate from `science_fingerprints()` so Markdown publication semantics remain unchanged.

Its comparison scope is:

- Current intake fingerprints, including optional-file additions and removals.
- `RESEARCH_STATUS.md`.
- Ordinary scientific files under `sources/`, `work/` and `outputs/`, including code, data and non-Markdown evidence.
- Canonical logical-task handoffs and other substantive handoff documentation.

Exclude generated indexes, private runtime state, terminal markers, preserved/proposed replacement copies, generated operational/decision receipts and frozen review-input copies. Keep immutable evidence integrity checks separate; corrupted snapshots must fail visibly rather than become an ordinary reopening trigger.

Use project-relative paths and content hashes, with existing safe-path and regular-file handling. Detect additions, modifications and deletions. Do not follow links or treat unreadable/special files as valid evidence versions. Do not crawl unrelated projects or introduce a dependency graph.

Store a `completion_baseline` on the successful COMPLETE proposal in opposition history. Include the intake/scientific maps and its proposal identity/version. This preserves earlier baselines naturally across subsequent completions.

Capture the baseline after quiescent publication and the final status update, before acknowledging COMPLETE. Preserve the existing reviewed-version checks. Ensure a human edit during finalization cannot be silently absorbed into the baseline as though it were reviewed: compare across the final writes, allowing only known controller-produced changes. A failed baseline write or version recheck prevents acknowledgement.

Advance the operational schema to **10**, reflecting the required completion-baseline contract. Update diagnostics and current fixtures; reject older operational state without migration.

Assumption: changes to substantive project science are conservative candidates for reassessment. Agents determine scientific relevance and affected findings. Byte-identical files remain unchanged even if timestamps differ.

**2. Distinguish existing completion from reopening and recovery**

Affected functions: `load_state()`, `restore()`, `prepare_resume()`, `start_resumed()` and `cli.run()`.

Remove the blanket COMPLETE refusal. Preserve exclusive ownership and distinguish:

- **Acknowledged COMPLETE with unchanged relevant versions:** report existing completion and return success without a replacement context, quota RPC, scientific turn, job or research monitors.
- **Acknowledged COMPLETE with changed relevant versions:** proceed through owned reopening.
- **Unacknowledged/interrupted finalization:** use operational recovery when the current-format records and handoffs provide a valid basis. Never report this as acknowledged completion or manufacture the missing ACK.
- **Corrupt required completion records:** fail explicitly, retaining markers, science and reservations.

Reconcile actual recorded owners before replacement admission. Saved cleanup flags remain insufficient. Uncertain ownership blocks admission.

Give preparation an explicit result, such as a Boolean indicating whether research was admitted, and propagate it through `start_resumed()` to `cli.run()`. The unchanged result must return before the CLI creates the primary runner. Handle repeated unchanged calls consistently; they must not be mistaken for interrupted transactions.

For unchanged completion, preserve marker bytes and canonical scientific files. Ownership observations may be recorded, but do not rewrite status, generate scientific handoffs or invalidate agreement. No quota is needed because no research is admitted.

Keep `start --preserve-existing` unable to bypass existing runtime or terminal records.

**3. Extend the existing transaction to reopen COMPLETE safely**

Affected functions: `prepare_resume()`, `commit_resume()`, `successor_documents()`; existing workspace marker helpers.

For changed completion:

1. Archive exact terminal bytes, prior terminal fields, completion baseline and prior explanation in the continuation attempt.
2. Reconcile owners and retained job outcomes using M2 behavior.
3. Reread authoritative questions, optional instructions and feedback.
4. Resolve retained immutable handoffs before replacing the primary’s objective with the current questions.
5. Compute and retain changed paths, categories, old/new hashes and addition/modification/deletion status.
6. Perform existing backend/isolation/allocation preparation and obtain actual fresh weekly quota strictly above 15%.
7. Prepare the fresh primary context without enabling research.
8. Recheck markers, authoritative intake, relevant scientific versions and quota synchronously before commit.

Compare scientific versions again at commit, extending the existing intake-only recheck. A correction made during preparation must prevent admission against the earlier version.

Generalize marker removal to applicable `STOP`, `STOP_ACK`, `COMPLETE` and `COMPLETE_ACK`, using the existing exact-byte archive, digest checks, persistence and rollback rules. Do not remove a marker changed by the human during preparation.

On successful commit:

- Mark current science as requiring reassessment rather than complete.
- Invalidate the prior proposal’s terminal authorization while retaining its proposal, review, objections, final request and completion baseline.
- Preserve investigation/task/job identities, cumulative usage, earlier attempts, human grants and immutable documents.
- Keep released tasks released. Reactivate the existing logical opponent only through a fresh terminal proposal.
- Preserve the existing requirement to inspect retained job outcomes before replacement computations.

Failed preflight, insufficient/unavailable quota, changed inputs, persistence failure or uncertain candidate cleanup must retain the previous completion explanation and matching marker bytes where rollback remains safe. Keep concurrent human changes untouched and report interrupted rollback honestly.

Do not automatically restart research after a quota reset.

**4. Make changed direction visible and scientifically actionable**

Affected files: `src/research_pipeline/collaboration.py`, `src/research_pipeline/codex.py`.

Expose reopening metadata through `successor_documents()` and existing `control(check/tasks)` responses. Include:

- Previous completion identity and retained decision-note path.
- Changed documents and exact versions.
- Changed questions/instructions/feedback.
- The requirement to assess implications and retain unaffected findings.
- The distinction between prior completion and current reassessment.

Use the existing document/list paging conventions for larger change sets; avoid another tool or schema family.

Extend `codex.prompt()` to require the resumed primary to:

- Read current versions alongside historical evidence.
- Explain added, revised or removed objectives.
- Identify which assumptions/results require reconsideration and which remain useful.
- Update `work/PLAN.md`, `RESEARCH_STATUS.md` and its handoff with changed-document links and scientific implications.
- Obtain fresh opposition before another COMPLETE.

Questions remaining unchanged must not suppress reopening for evidence, documentation or corrective feedback.

Make a concise reopening summary available through the existing continuation note/status mechanism. Apply existing baseline checks to status updates. If a human-edited status cannot be updated safely, retain it verbatim, stage the revision and expose the pending incorporation clearly. The primary must use the existing exact-version `incorporate_edit` operation before accepted replacement.

Do not generate scientific implications deterministically from filenames. Runtime metadata describes changes; the scientific agent explains their consequences.

**5. Reread human direction at relevant checkpoints**

Affected functions: `science_intake()`, `checkpoint_prompt()`, `pause_checkpoint()`, `rollover()`.

Share the small current-direction construction already present in pause checkpointing with rollover checkpointing. Supply current questions, optional instructions, feedback, changed input paths and current canonical Markdown changes.

Allow the comparison logic to inspect the active context’s saved baseline, rather than always selecting its predecessor. An initial context must detect an edit made after attachment; the checkpoint must not adopt that edit as its new baseline silently.

Keep required handoff identity/objective metadata consistent with the logical task while recording changed direction and its implications for continuation.

Preserve existing enforcement:

- Exact human-hash and draft-hash incorporation.
- Later edits invalidate earlier incorporation.
- Unacknowledged replacements remain proposals.
- Retired-delegate corrections use the primary’s existing incorporation path.
- Protected inputs and frozen evidence remain read-only.
- Pause checkpoint permissions and quota interruption behavior remain unchanged.

**6. Consequential tests and acceptance criteria**

Add `tests/test_v0_l5_reopening.py`. Reuse the existing decision fixtures to create an acknowledged COMPLETE through actual finalization logic, and reuse the resume backend fixtures for admission. Label all substituted quota and scientific judgments as engineering fixtures.

Replace `test_complete_is_a_read_only_refusal` with the new supported behavior. Extend existing recovery, pending-document and cleanup tests where their established fixtures are appropriate.

Required cases:

| Case | Acceptance |
| --- | --- |
| Changed questions | Reopens with current objectives and changed-document metadata; prior findings remain available. |
| Added/changed evidence | Reopens with unchanged questions; include non-Markdown evidence. |
| Changed scientific documentation | Reopens and protects the corrected canonical text. |
| Corrective feedback | Reopens with unchanged questions and preserves feedback as distinct human input. |
| Changed optional instructions | Addition, revision or removal is visible to resumed intake. |
| Unchanged completion | Repeated resume returns existing completion without native admission or marker changes. |
| Timestamp/index/runtime-only changes | Do not repeat research. |
| Failed/concurrent launch | Exact COMPLETE/ACK and prior explanation survive; no scientific admission. |
| Change during preparation | Commit refuses stale versions and preserves the newer human content. |
| Interrupted marker transaction | Recovery reconciles the candidate before another admission and restores only its own removals. |
| Fresh completion | Old proposal/version cannot finalize; the same logical opponent reassesses a new proposal, and renewed agreement is required. |
| Human edit during checkpoint/publication | Current text is reported and retained; stale incorporation cannot authorize replacement. |

Also establish:

- Unaffected artifacts and immutable snapshots retain their bytes/identities across reopening.
- Usage and previous job outcomes are unchanged.
- A substantive new objection prevents COMPLETE.
- Successful renewed completion creates a fresh baseline; immediate unchanged resume does not reopen again.
- Baseline persistence/version-check failure prevents COMPLETE_ACK.
- Unacknowledged COMPLETE never returns “already complete.”

Suggested Writer verification, using the inherited dependency path:

```sh
/home/francesco/miniconda3/bin/python -m unittest tests.test_v0_l5_reopening tests.test_v0_l5 tests.test_v0_l5_recovery tests.test_v0_l4 tests.test_v0_l4_cleanup tests.test_pending_documents
/home/francesco/miniconda3/bin/python -m unittest discover -s tests
```

Routine fixture checks keep paid gates disabled. Trusted final/combined stages retain the authorized enabled L5 gate and fresh private output destinations. Enabled missing prerequisites fail visibly. Preserve restricted-Writer bus failures; do not create a workaround.

**7. Documentation and milestone handoff**

Update:

- `development/requests/v0-l5-continuity.md`
- `README.md`
- Relevant `FOLDER_CONTENT.md` indexes, including tests and source entries.

Document schema 10, reopening triggers, unchanged completion, renewed opposition, human-edit handling and operational recovery of unacknowledged finalization. Remove current claims that COMPLETE reopening is unsupported while retaining historical M1/M2 limitations accurately.

Record actual implementation refs, commands, receipts, review outcomes and limitations. Keep fixture evidence distinct from native science. State that trusted process validation, resumed native science, final/combined acceptance and L6 remain outstanding unless subsequently demonstrated.

Do not modify manager-owned `STATUS.md`, human requirements, protected starting evidence, historical receipts or the retained M5 candidate. Do not expand this milestone into native-harness delivery, L6 or private M5 work.
