Reproduced the defect before repair. Passed two focused tests, 186 affected tests, and full discovery: 401 tests with nine gates skipped. Compilation passed.
