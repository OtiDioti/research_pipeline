Complete milestone diff: milestones/002/diffs/9f8c4e633e67.diff
