Complete milestone diff: milestones/002/diffs/e370ca755596.diff
