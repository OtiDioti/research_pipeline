<!-- cwi:decisions -->
Fixed both P1 findings: primary checkpoint quota refresh preserves the admission block, and active checkpoints interrupt on quota cutoff or operational failure. Updated documentation. COMPLETE reopening remains deferred.
<!-- /cwi:decisions -->

<!-- cwi:tests -->
Pause tests: 12 passed. Affected regression: 257 passed. Discovery: 362 tests, nine skipped; all executed tests passed. Compilation passed.

Enabled production gate failed preflight because the authorized user bus is unavailable; no services launched. Failed receipt retained. Trusted-host validation and independent re-review remain pending; M2/L5 acceptance is not claimed.
<!-- /cwi:tests -->
CWI: ready
