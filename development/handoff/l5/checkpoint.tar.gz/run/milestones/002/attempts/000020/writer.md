<!-- cwi:decisions -->
Fixed both findings: resolved owner errors are archived after successful operations, while outstanding preservation failures remain blocking. Cached handoffs now verify linked immutable documents against recorded hashes. Updated documentation.
<!-- /cwi:decisions -->

<!-- cwi:tests -->
Passed: 18 focused recovery tests, 264 affected regression tests, compilation, and discovery of 370 tests with nine gates skipped.

Trusted systemd/Bubblewrap validation remains pending because the authorized user bus is unavailable. COMPLETE reopening remains deferred.
<!-- /cwi:tests -->
CWI: ready
