<!-- cwi:roadmap -->
1. **L5-M1 — Owned explicit resume: source review approved.** Preserve locked resume, fresh quota preflight, immutable handoffs, cumulative accounting and the distinction between cleanup evidence and observed computation outcomes. Native and final/combined acceptance remain pending.
2. **L5-M2 — Pause and crash recovery: next.** Complete investigation-wide checkpointing and suspension, terminate contexts after controller death, recover retained checkpoints and reconcile computations before replacement admission. Establish behavior with real local processes.
3. **L5-M3 — COMPLETE reopening and human direction.** Reopen selectively for changed questions, relevant evidence/documentation or corrective feedback; preserve human edits and unaffected science; require renewed opposition.
4. **L5-M4 — Native validation and delivery.** Complete the L5 native gate with actual resumed primary/opponent science, finish documentation and independent review, and pass required final/combined verification. L6 and private M5 remain separate.
<!-- /cwi:roadmap -->

<!-- cwi:roadmap-changes -->
M1 already implements substantial job-outcome reconciliation, deferred publication and checkpoint reconstruction. M2 should reuse these mechanisms.

Introduce the process-validation portion of `RESEARCH_PIPELINE_V0_L5_NATIVE=1` in M2 because production service cleanup needs trusted-host evidence. M4 will extend that gate with resumed native scientific execution. Process fixtures alone cannot establish scientific continuity or sufficient real quota.
<!-- /cwi:roadmap-changes -->

<!-- cwi:plan -->
**Next milestone: L5-M2 — investigation-wide pause and controller-crash recovery.**

Deliver explicit recovery from supported operational states using M1’s admission transaction. A successful pause must stop all owned writers and retain usable continuation information. Controller death must terminate context services without waiting for a subsequent CLI command. Computations may survive temporarily within their original independently enforced deadlines; restart must reconcile and stop them before admitting replacement contexts.

COMPLETE reopening remains outside this milestone. Preserve every COMPLETE marker and acknowledgement for M3.

**Findings that determine the implementation**

The inspected source establishes these concrete gaps:

- `Coordinator.restore()` rejects crash/failure states and changed boot identity. `prepare_resume()` supports only STOP and confirmed pause.
- `_block_and_cleanup()` interrupts and closes contexts without requesting fresh checkpoint handoffs. After the global admission latch is set, both `native_turn()` and `draft()` prevent an ordinary checkpoint turn.
- `cli.pause_async()` duplicates cleanup logic, skips contexts with saved `cleanup_ok=True`, and checks only active jobs. Its 30-second acknowledgement bound does not accommodate a checkpoint operation.
- `RunningService.start()` launches an isolated context service directly. Neither that service nor `RunningService.close()` establishes an explicit controller-death guarantee.
- `close_context()` captures drafts, job metadata and immutable documents for live context objects. Restart reconciliation currently marks reconstructed contexts closed without performing equivalent checkpoint capture.
- `JobManager.reconcile(force=True)`, `cancel()`, `outcome_observation` and independent job supervision already preserve racing completion/timeout evidence. Retain the M1 repairs: an absent service or empty cgroup establishes cleanup, not an observed cancellation.
- Historical `operational_failure` and task `context_error` fields would incorrectly affect a resumed attempt unless their current versus historical meaning is handled at admission.

No source was modified or development command executed during planning.

**1. Extend reconstruction and the admission transaction**

Affected files: `src/research_pipeline/collaboration.py`, `src/research_pipeline/cli.py`; extend `tests/test_v0_l5.py` and add `tests/test_v0_l5_recovery.py`.

Extend `Coordinator.restore()` with an internal cleanup-only mode used by offline pause. Keep the existing CLI surface: `resume PROJECT` and `pause PROJECT`.

- Normal restore may reconstruct supported operational outcomes: `starting`, `running`, `stopping`, `idle`, `failed`, `cleanup_unconfirmed`, `quota_unavailable` and `reassessment_required`, alongside existing STOP/pause outcomes. Reject unknown states clearly.
- An available exclusive project lock establishes that no cooperating foreground controller owns the investigation. It does not establish service cleanup.
- Do not require saved `cleanup_ok=True` for recovery. Reconcile actual ownership before considering replacement admission.
- Reconstruct cleanup capability without first requiring valid current scientific inputs, Codex authentication or backend availability. Missing questions or failed native prerequisites must not prevent cleanup of known owned processes.
- Read current intake after ownership reconciliation and before preparing the successor. Use M1’s marker archive, fresh quota observation, input/version checks, rollback and synchronous commit boundary.
- Preserve the original explanation and runtime failure in the continuation archive. Operational recovery never creates a scientific STOP, agreement or acknowledgement.
- Keep any COMPLETE marker/acknowledgement as a read-only refusal for execution. Cleanup-only pause may reconcile processes while preserving its scientific record.
- Continue to refuse automatic recovery across a changed boot identity, retaining reservations and reporting the precise limitation. This milestone covers controller failure within the same host boot.

Advance the operational schema to **9** to identify the controller-supervision contract. Update schema diagnostics and current fixtures; reject unsupported state without migration. Preserve historical files.

Record a controller instance identifier and verified Linux process identity for each newly launched context. Stable investigation/task/job identities and saved usage remain unchanged.

At successful admission, archive and clear only operational latches that belong to the interrupted attempt, including current task `context_error` flags. Preserve predecessor diagnostics, accounting-incomplete observations, opposition history and prior attempts. Failed preparation must retain the previous failure explanation.

**2. Share ownership reconciliation between resume and offline pause**

Affected functions: `reconcile_resume_ownership()`, `prepare_resume()`, `close_context()`, `snapshot_job_documents()` and `cli.pause_async()`.

Replace the duplicated offline cleanup loop with one coordinator-owned reconciliation routine. Its callers record returned observations in their pause/recovery attempt.

For every recorded context and job, including terminal records:

1. Honor durable evidence that launch was never attempted.
2. Otherwise verify boot, saved invocation, expected unit and allocation membership before signaling.
3. Reconcile jobs with `force=True`; cancel only work still active after reconciliation, preserving completion/timeout races and retained outputs.
4. Confirm context/service cleanup and recorded cgroup emptiness.
5. Retain uncertain records and capacity when identity or cleanup cannot be established.

Do not infer ownership from a unit name or unchecked PID. Missing ownership after an uncertain launch remains a visible reservation, even if another record claims successful cleanup.

After confirmed context cleanup, perform the stopped-writer preservation work currently available through `close_context()`:

- Capture its deterministic private draft directory through `Documents.capture()`.
- Retain full owned-job details, not only the paginated summary.
- Preserve immutable document IDs, publication baselines and existing incorporation acknowledgements.
- Set predecessor links and pending publication without resurrecting old clients, sockets, native threads or authentication homes.
- Make repeated reconciliation idempotent: settled documents/publications must not be recaptured or overwritten.

Use `Allocation.restore()` only after known ownership cleanup succeeds. Existing checks for empty allocation membership and exact caps must also pass before preparation.

**3. Make human pause checkpoint before closure**

Affected functions: `schedule_shutdown()`, `_block_and_cleanup()`, `native_turn()`, `draft()`, `dispatch_rpc()` and `checkpoint_prompt()`.

Keep one common shutdown path. Add a narrowly scoped internal pause-checkpoint phase:

- Latch investigation-wide admissions synchronously before awaiting anything.
- Stop computational jobs concurrently with context preparation. Settling job admissions must observe the latch before releasing commands.
- Interrupt ordinary native turns and wait for their in-flight turn operations to settle. Serialize native turns per context so a checkpoint cannot overlap an unfinished turn.
- Do not await the full `run_task()` wrapper: its `finally` can already be waiting for shutdown, which would deadlock.
- For healthy attached contexts with sufficient fresh quota, request a bounded checkpoint using the existing handoff prompt and validation rules. Include primary, researchers, verifiers and opponent; preserve opponent objections and review history.
- During this phase, permit only scoped checkpoint draft writes and existing read/status operations. Continue rejecting computations, delegation, new contexts, proposals, finalization and other scientific admissions.
- Keep the permission internal and tied to the current context/pause operation. Do not expose a model-controlled bypass or add MCP tools.
- Preserve inventory and context-telemetry validation.

Quota cutoff or missing required quota telemetry preempts checkpoint inference. Proceed directly with available drafts and cleanup, retaining the actual quota/operational outcome.

Checkpoint failure, timeout, interrupt failure or persistence failure must never disable process cleanup. After stopping writers, validate immutable final handoffs and record which tasks lack one. Keep cleanup confirmation separate from preservation success.

Update `pause_async()` so it:

- Never returns success from stale saved cleanup flags.
- Uses the shared cleanup-only reconstruction when the foreground lock is available.
- Preserves existing scientific/quota terminal explanations and markers.
- Uses an acknowledgement bound derived from the bounded checkpoint and cleanup operations instead of the unrelated fixed 30 seconds.
- Returns failure on acknowledgement expiry or incomplete preservation, while accurately reporting any confirmed suspension and retained request.

A usable existing checkpoint may substitute when no new checkpoint can be obtained; report its age/source and possible lost progress.

**4. Enforce context termination after controller death**

Affected file: `src/research_pipeline/isolation.py`; add a small trusted `src/research_pipeline/context_supervisor.py`.

Wrap context execution with a Linux supervisor inside the existing context service and allocation. This is process supervision, not another research controller.

Use a pidfd bound to the foreground controller process:

- Record boot identity, PID and `/proc` process-start identity before launch.
- The supervisor opens the pidfd and verifies the process-start identity around acquisition. Missing, changed or unsupported identity fails closed.
- Launch the existing Bubblewrap/app-server command only after establishing the lifetime guard.
- Preserve stdin/stdout protocol transport directly; supervisor diagnostics must not contaminate app-server JSON output.
- Observe controller death independently of controller Python cleanup, RPC availability or a future restart.
- On controller death, terminate the context child and exit. Existing systemd `KillMode=control-group`, bounded shutdown and SIGKILL escalation must remove remaining descendants.
- Keep every child inside the same capped slot. No context `RuntimeMaxSec`, scientific lifetime, new resource grant or additional daemon.
- Retain a small private supervisor observation identifying context/controller and exit cause. It is diagnostic evidence; only actual service/cgroup observations confirm cleanup.

Integrate this through `RunningService.start()` and preserve normal `RunningService.close()` behavior. Do not change computation supervision to follow controller lifetime: jobs retain their original independent deadlines.

Record owned temporary-resource paths where necessary for safe post-crash cleanup. Never reuse old authentication homes or RPC endpoints, expose credentials to jobs, or delete unrelated temporary directories.

**5. Recover usable checkpoints and report limitations**

Affected functions/files: `resume_basis()`, `successor_documents()`, `codex.prompt()`, publication/status handling and relevant workspace descriptions.

After actual cleanup:

- Validate any captured handoff from the interrupted context using existing document hashes, scope checks and handoff rules.
- If unavailable, search that logical task’s predecessor chain for its latest usable immutable handoff. Distinguish a missing/incomplete latest checkpoint from corrupted immutable evidence; corruption must fail visibly.
- Retain newer partial documents and computational outputs alongside an older recovery checkpoint.
- Require a usable primary continuation basis before scientific admission. Preserve the existing narrowly defined quota-STOP fallback. With no safe basis, finish cleanup and refuse execution honestly.
- Carry all retained job IDs into successor reconciliation, including completed, cancelled, timed-out and unavailable outcomes beyond summary pagination. Keep individual inspection mandatory before new computations.
- Preserve logical opponent identity, unresolved objections, retirement state and prior proposals. Invalidate pending terminal authority before resumed scientific work.

Write an ordinary operational recovery/pause note containing actual cleanup, retained checkpoints, interrupted tasks/jobs, missing handoffs, uncertain outcomes and possible lost progress. Never manufacture a scientific summary.

Update `RESEARCH_STATUS.md` and indexes through existing version-bound preservation rules. Preserve a human-edited status verbatim when it cannot safely be incorporated; point to the retained note through runtime/CLI diagnostics.

**6. Consequential tests and real-process evidence**

Reuse M1 outcome-race tests and the L4 real cleanup regression. Add coverage for these distinct behaviors:

| Case | Required observation |
| --- | --- |
| Human pause with two active contexts and a job | Admissions block first; checkpoint turns do not overlap work turns; all owned descendants stop; usable handoffs and partial outputs survive. |
| Checkpoint capability restrictions | Checkpoint drafts succeed; job/delegate/context/decision admission remains blocked. |
| Checkpoint or save failure | Cleanup still runs; no unqualified successful pause or invented handoff. |
| Offline pause with stale cleanup flags | Every saved owner is rechecked; actual remaining work cannot be skipped. |
| Operational-state resume | Cleanup and checkpoint recovery precede fresh quota preflight; failed preparation preserves explanations and markers. |
| Interrupted admission/continuation | No duplicate launch or transport; uncertain ownership retains reservations. |
| Missing latest checkpoint | Older usable checkpoint is identified with loss warnings; absent safe primary basis refuses admission. |
| Retained job outcomes | Completed/timeout/cancellation evidence survives restart; unavailable outcome remains unavailable. |
| Resumed attempt diagnostics | Historical failure stays accessible without automatically failing the new healthy attempt; cumulative usage remains cumulative. |
| Human edits and opposition | Recovery publication preserves edits; same opponent/history survives; stale authorization cannot finalize. |

Add `tests/test_v0_l5_process.py` under `RESEARCH_PIPELINE_V0_L5_NATIVE=1`, requiring `RESEARCH_PIPELINE_V0_L5_OUTPUT_DIR` and fresh private receipt reservation. Reuse the existing output-reservation mechanism.

Trusted-host process exercises must establish:

- SIGKILL of a controller subprocess stops its actual capped context services and descendants **before any restart**, retaining written outputs.
- A separate computation retains its identity and original deadline after controller death; independent expiry stops descendants and preserves partial results without a job monitor.
- Restart reconciles retained outcomes and usable checkpoints under the exclusive lock before any replacement admission.
- Concurrent recovery is rejected.
- An uncertain ownership/launch case blocks replacement and reports retained capacity.
- Real pause leaves no owned context/job descendants running.

Use public engineering programs and production systemd/Bubblewrap boundaries. These receipts must explicitly identify process fixtures and absence of native scientific inference. Do not use fixture quota as evidence of sufficient real quota. Full successful native resumption remains M4.

Enabled missing prerequisites fail visibly. Restricted Writer bus failures do not authorize a replacement bus or isolation fallback. Operational test expiry records failed/interrupted validation.

**7. Verification and delivery**

The Writer should run focused recovery/L5 checks and affected L1–L4, app-server and pending-document tests, followed by ordinary discovery. Use the authorized Python and existing dependency path from the brief. Keep historical live gates and accepted L1–L4 native gates disabled; exercise changed supervision through the new L5 process checks.

Record actual commands, results, receipt destinations, cleanup and limitations in `development/requests/v0-l5-continuity.md`. Update README and affected directory indexes, including the new supervisor/test files. Correct active M1-only descriptions while preserving historical outcomes.

Do not modify manager-owned `STATUS.md`, governing human files, protected inputs, historical receipts or the retained M5 branch/worktree. Independent review must examine checkpoint permissions, controller-death enforcement, uncertain ownership, outcome evidence and admission ordering. Trusted validation pending must remain explicit; M2 source approval does not accept all L5.

**Milestone acceptance**

M2 is complete when successful pause demonstrably suspends all owned work with usable continuation information; controller death independently terminates context descendants; explicit recovery reconciles actual jobs and checkpoints before quota-gated admission; uncertain cleanup blocks replacement; and consequential tests plus trusted real-process receipts support those claims.
<!-- /cwi:plan -->
CWI: next
