Fixed recovery inspection before resume initialization and handoff links to human inputs. Preserved saved-science requirements and input protections. Updated documentation and regression tests.
