Complete milestone diff: milestones/005/integration-1/diffs/a152d0f3a90a.diff
