Resolve integrated test failures.
New or changed test failures; regressions or flakiness require repair. Comparison is conservative.
Read complete failure output using artifact pages: tests/final-002.txt
