Complete milestone diff: milestones/005/integration-3/diffs/dad222eee689.diff
