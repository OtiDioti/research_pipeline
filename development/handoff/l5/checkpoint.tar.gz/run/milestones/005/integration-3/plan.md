Resolve integrated test failures.
Recorded final verification failed; repair before rerunning tests.
Read complete failure output using artifact pages: tests/final-005.txt.commands/0001.txt
