<!-- cwi:decisions -->
Fixed P2: the gate now verifies the resumed opponent receives its exact predecessor handoff and historical opposition metadata. Added a regression rejecting missing or corrupt delivery, including paginated history.

Updated the continuity report. No production changes. Trusted native/process and final/combined validation remain pending.
<!-- /cwi:decisions -->
<!-- cwi:tests -->
- Affected suite: 90 tests, one skipped.
- Full discovery: 411 tests, ten skipped.
- Compilation passed.

All executed tests passed.
<!-- /cwi:tests -->
CWI: ready
