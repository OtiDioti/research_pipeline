**Next milestone: L5-M4 — Native validation and delivery**

Complete the remaining L5 validation and delivery work. Keep production changes limited to defects demonstrated by the new checks.

No source was modified or development command executed during planning.

**Findings determining the implementation**

- `tests/test_v0_l5_process.py` already uses the required L5 opt-in flag and private output reservation. It exercises actual systemd/Bubblewrap processes, controller SIGKILL, independent job expiry, exclusive recovery, uncertain ownership and foreground pause.
- That gate substitutes quota and inventory. Its receipts cannot establish native scientific work or sufficient real allowance.
- No `tests/test_v0_l5_native.py` exists.
- The L4 native harness provides useful public questions, procedural instructions, passive control observation and packet/job provenance assertions.
- Its complete terminal assertion assumes all contexts remain in `runtime.contexts`. L5 reconstruction retains earlier contexts only in persisted records, so that assumption must not be copied.
- `cli.run()` now supports both ordinary owned resume and unchanged COMPLETE. Use this production lifecycle to exercise initialization, preparation, runners, finalization and closure.
- M3 deliberately distinguishes original reopening-trigger versions from the fresh admission snapshot. Native evidence should retain both rather than compare them as identical.

**1. Add the native discovery gate**

Create `tests/test_v0_l5_native.py` containing:

- One native test class gated by `RESEARCH_PIPELINE_V0_L5_NATIVE == '1'`.
- Ungated consequential receipt/provenance tests.
- Small fixture-local helpers for phase observation, continuity assertions and owned cleanup.

Require `RESEARCH_PIPELINE_V0_L5_OUTPUT_DIR` when enabled. Missing destination, authorized bus, isolation prerequisites, backend, authentication or sufficient actual weekly quota must fail visibly.

Reuse `reserve_validation_output()`. Each process/native invocation and each final/combined stage must reserve a distinct private destination. Record requested and actual destinations and print the actual receipt path.

Reuse narrow L4 helpers and public inputs where suitable. Import the L4 module rather than exposing imported `TestCase` classes to discovery. Avoid a generalized validation framework or broad harness refactor.

Expected production interfaces remain:

```python
await cli.run(project, isolation.Config())
await cli.run(project, resume=True)
collaboration.load_state(project)
collaboration.terminal_acknowledged(project, state)
```

The harness must not originate scientific proposal, review or finalization calls.

**2. Demonstrate native continuity in two scientific phases**

Create a fresh public/test project inside the reserved output. Reuse the L4 trapezoidal-error investigation or an equally small public mathematical problem requiring analytical reasoning, numerical work and independent criticism.

Keep default grants: two agents, 2048 MiB shared memory, zero swap, 128 tasks and one concurrent job.

Procedural instructions may require evidence filenames and tool usage. Agents supply all derivations, code, numerical observations, objections, conclusions and terminal decisions.

**Phase A — establish retained science**

Run the ordinary CLI lifecycle until an acknowledged scientific COMPLETE or scientific STOP.

Require:

- Actual primary and opponent native execution.
- Successful admitted numerical work from both roles.
- Immutable job reports explicitly linked into the corresponding scientific packets.
- Useful validated handoffs and independent opposition.
- Confirmed cleanup and genuine matching terminal markers.

Have the primary maintain a substantive `work/CONTINUITY.md` explaining findings, assumptions and remaining limitations. Retain its immutable version.

If Phase A reaches COMPLETE, invoke unchanged explicit resume before modifying inputs. Assert no new contexts, jobs, native threads or scientific document versions, and unchanged terminal-marker bytes.

**Operator edits while stopped**

Act explicitly as the test’s human operator:

- Add corrective `HUMAN_FEEDBACK.md`.
- Append a labelled clarification to canonical `work/CONTINUITY.md`.
- Keep questions and project instructions unchanged.

A suitable direction is to reassess frequency/resolution assumptions using an agent-selected oscillatory example. Supply no expected numerical answer or verdict.

Record exact before/after hashes and full human correction text. These are declared test inputs, separate from agent-authored science.

**Phase B — explicit owned resume**

Call the production resume lifecycle, reconstructing from persisted state.

If Phase A was COMPLETE, require the reopening branch with recorded feedback/document changes. If it was scientific STOP, require owned STOP continuation with its explanation and unresolved issues retained.

Require substantive resumed analytical work, new primary and opponent computations, and a new scientific proposal/review/finalization cycle.

Accept an acknowledged scientific COMPLETE or scientifically justified STOP. A quota stop, operational failure, fixture expiry or absence of substantive resumed work fails this demonstration. Record the actual branch; a STOP continuation does not establish live COMPLETE reopening.

All separate reopening-trigger cases remain covered by M3’s consequential tests. Do not force a scientific verdict to obtain coverage.

**3. Make continuity evidence specific to the resumed phase**

Observe existing authenticated control calls passively, following the L4 pattern. Forward arguments, results and exceptions unchanged.

Record phase, logical task/context/native-thread identities, submitted-document hashes, proposal versions and paginated review reads. Observe incorporation calls and relevant intake/change metadata. Do not inject decisions, quota, occupancy, clocks or scientific documents.

Assertions must establish:

- Stable investigation and logical opponent identities across phases.
- Fresh native context/thread identities after resume.
- Actual native quota provenance and allowance strictly above 15% at resumed admission.
- Old markers archived exactly and cleared before resumed scientific admission.
- Prior proposals, reviews, final requests, objections and immutable evidence retained.
- Prior terminal authority invalidated; Phase B uses a new proposal/version and delivered review.
- Original job identities, deadlines, launch counts and observed outcomes retained without relaunch.
- Earlier usage records preserved and cumulative accounting extended.
- The successor receives the validated predecessor handoff and current feedback/correction versions.
- Status, plan and scientific notes explain changed direction and its implications while retaining applicable earlier findings.
- The human correction is incorporated using its exact hash and preserved through the existing version-bound mechanism.

Identify Phase B jobs and contexts by their newly admitted IDs. Earlier computations must not satisfy resumed-work assertions. Require each role’s new successful job report to match evidence in its Phase B packet.

Verify frozen manifests as JSON arrays and check packet versions and source hashes. Reuse the existing numerical-report provenance helper against a phase-filtered job view.

Resolve historical context paths from persisted IDs/project paths. Do not require reconstructed contexts to exist in the current in-memory context dictionary.

Preserve starting evidence and instructions byte-for-byte. Compare feedback against the intentionally changed operator version for each phase, rather than incorrectly expecting the entire intake map to remain unchanged across operator edits.

**4. Preserve truthful receipts and cleanup on every exit**

Use explicit operational test bounds, separate from runtime scientific policy. A reasonable initial bound is 2400 seconds for both native phases, with a separate 120-second cleanup bound. Expiry means failed/interrupted validation and must never request scientific STOP or COMPLETE.

Persist an initial receipt before prerequisite checks. Update it at phase boundaries and write final failure details from `finally`.

Include:

- Validation kind and requested/actual output paths.
- Executed lifecycle actions and implementation/source identity when available.
- Per-phase runtime snapshots and terminal hashes.
- Native quota, inventory and measurement evidence paths/hashes.
- Continuation archives, handoff IDs, change versions and opponent history.
- Phase-specific jobs, commands, original deadlines and numerical-report IDs.
- Intended human edits and protected-input comparisons.
- Actual service ownership, cleanup observations and remaining uncertainty.
- Operational interruption details and limitations.

On normal exit, failure or cancellation:

1. Let the production lifecycle perform its cleanup.
2. Obtain exclusive ownership for any additional cleanup-only reconciliation.
3. Inspect every launched context/job owner and actual cgroup emptiness.
4. Preserve uncertain reservations and report missing ownership honestly.
5. Close transports and reap fixture processes.
6. Mark the receipt passed only after all scientific-continuity and cleanup assertions pass.

Do not substitute `science_quiescent()` or saved cleanup flags for actual process observations. Retain failed admissions and partial outputs.

Preserve engineering-root terminal-marker presence and bytes.

Apply only small reporting changes to `tests/test_v0_l5_process.py`: persist its initial receipt before preflight and expose its actual reserved destination. Keep its synthetic admissions clearly labelled. Repair process behavior only if trusted execution demonstrates a defect.

**5. Add meaningful ungated checks**

Exercise the observer and failure handling without inference:

- Reject a “resumed” receipt whose numerical evidence comes entirely from Phase A.
- Reject missing/mismatched job-report snapshots, stale proposal versions or absent renewed opposition.
- Verify enabled prerequisite failure retains a failed receipt before any scientific launch.
- Verify repeated output requests preserve earlier receipts.
- Verify operational expiry remains failed/interrupted even when cleanup succeeds.

Reuse existing output-reservation and L4 packet/provenance tests where they already cover the same behavior.

Rerun M1–M3 continuity, reopening, pending-document and cleanup regressions if implementation changes affect those paths. Any discovered runtime defect needs a focused consequential regression and independent review.

**6. Verification and trusted-stage requirements**

Use the supplied Python and existing MCP dependency path. Do not install replacements or change authentication/isolation to accommodate the restricted Writer.

Routine Writer checks keep native/live gates disabled:

```sh
/home/francesco/miniconda3/bin/python -m unittest tests.test_v0_l5_native tests.test_v0_l5_process tests.test_v0_l5_reopening tests.test_v0_l5_recovery tests.test_v0_l5 tests.test_v0_l4 tests.test_v0_l4_cleanup tests.test_pending_documents
/home/francesco/miniconda3/bin/python -m unittest discover -s tests
```

Run compilation for changed Python files.

Trusted final and combined verification must each run ordinary discovery with:

- `RESEARCH_PIPELINE_V0_L5_NATIVE=1`.
- The inherited `RESEARCH_PIPELINE_V0_L5_OUTPUT_DIR`.
- The authorized host user bus and native file authentication.
- Historical M1–M5 live gates and accepted L1–L4 native gates disabled.

Both L5 native and process tests must execute in each trusted stage. Retain distinct actual receipt paths, command logs and results.

Restricted Writer bus failure permits source review with trusted validation pending. It does not authorize a bus workaround, disabled trusted gate or acceptance by fixture counts. Do not alter the pipeline/controller to create another validation path.

**7. Documentation, review and delivery**

Update:

- `development/requests/v0-l5-continuity.md`
- `README.md`
- Relevant source/test/request `FOLDER_CONTENT.md` indexes.

Explain the shared L5 opt-in flag, separate process/native evidence, two-phase continuity scenario, actual terminal branches, output reservation and operational-bound semantics.

Keep historical failures intact. Distinguish reported earlier test results from fresh M4 receipts. Preserve the accepted L4 refs and acceptance authority while marking its older pending passages as historical where necessary.

Independent pipeline review should examine native provenance, phase-specific evidence, exact-version human incorporation, opponent continuity, cleanup and receipt failure handling.

L5 delivery requires:

- Approved source review.
- Passing consequential checks and discovery.
- Passing actual native resumed primary/opponent work.
- Passing trusted real-process validation.
- Passing required final and combined verification with fresh receipts.
- Recorded refs, commands, output paths, cleanup and limitations.

Until trusted evidence exists, report source readiness and pending validation explicitly. Do not claim L5 completion.

Leave manager-owned `STATUS.md`, human requirements, protected evidence, historical receipts and the retained M5 branch/worktree untouched. L6 integrated lifecycle validation, M5 harness reconciliation, private science and human M5 acceptance remain subsequent dependencies.
