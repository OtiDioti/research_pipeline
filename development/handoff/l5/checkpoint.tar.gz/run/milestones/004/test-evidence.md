- Affected suite: 90 tests, one skipped.
- Full discovery: 411 tests, ten skipped.
- Compilation passed.

All executed tests passed.
