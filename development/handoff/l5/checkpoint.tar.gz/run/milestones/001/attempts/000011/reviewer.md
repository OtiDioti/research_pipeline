**[P2] An already-absent service is still recorded as observed cancellation.** At [jobs.py:387](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/jobs.py:387), `cleanup['confirmed']` alone authorizes `cancelled`.

If `_reconcile()` observes an active job, but the service disappears before `stop_owned()` observes it, an absent unit and empty cgroup produce confirmed cleanup without issuing any stop. With no final supervisor result or prior outcome, `cancel()` nevertheless saves an observed cancellation and claims “Owned service stopped on cancellation.” Restart then preserves this unsupported outcome.

Distinguish confirmed cleanup from an actual cancellation action. Preserve an unavailable command outcome when the service was already absent, while retaining the cancellation request. Add a regression using real `stop_owned()` with active → absent observations, an empty cgroup, and no final result; verify no stop command or observed cancellation.

The previous timeout-evidence finding is addressed. I read the complete updated diff and supporting evidence; no tests were executed or files modified.

CWI: changes_requested
