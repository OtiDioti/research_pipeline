Complete milestone diff: milestones/001/diffs/e837046fba4e.diff
