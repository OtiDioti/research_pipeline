**[P2] Timeout evidence can still be lost during cancellation.** At [jobs.py:380](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/jobs.py:380), timeout classification depends on the final properties returned by `stop_owned()`.

If reconciliation first observes an active job, then `stop_owned()` observes the owned service with `Result=timeout`, stopping/collecting that unit can leave its final properties as `LoadState=not-found`. `stop_owned()` discards the earlier timeout observation. Without a final supervisor result or prior outcome, `cancel()` consequently records `cancelled`; resume then preserves that incorrect outcome.

Preserve verified timeout observations across cleanup, separately from the final cleanup status. Add a regression using the real `stop_owned()` path with sequential active → owned timeout → absent observations and no final supervisor result. The current timeout regression mocks `stop_owned()` itself, hiding this loss.

I read the complete diff and supporting artifacts. No files were modified and no tests were executed.

CWI: changes_requested
