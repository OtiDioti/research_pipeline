**[P2] Unconfirmed cancellation is saved as an observed cancellation.** In [jobs.py:395](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/jobs.py:395), `cancel()` calls `remember_outcome()` even when cleanup is unconfirmed and no final supervisor result exists. For example, a foreign invocation can prevent any stop signal, yet the saved observation says `cancelled` with the explanation “Owned service stopped on cancellation.”

When a later reconciliation finds the service absent and no final result, it retains this observation and reports cancellation as the actual outcome. This converts a rejected cancellation request into a claimed result.

Only retain cancellation as observed when supported by confirmed termination or authoritative outcome evidence. Otherwise preserve the uncertainty and cancellation request separately. Add a regression starting without a prior outcome: reject cleanup, then reconcile an absent service with no final result and verify that cancellation is not claimed.

The previous publication and timeout-preservation findings are addressed. I read the complete current diff and supporting evidence; I did not run tests.

CWI: changes_requested
