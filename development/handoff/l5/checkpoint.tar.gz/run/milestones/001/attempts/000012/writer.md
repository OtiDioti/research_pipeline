<!-- cwi:decisions -->
Separated confirmed cleanup from cancellation evidence. Already-absent or inactive services retain an unavailable outcome and the cancellation request. Restart no longer promotes lifecycle failure into an observed command outcome. Added real-cleanup regressions and updated the continuity report.
<!-- /cwi:decisions -->

<!-- cwi:tests -->
Reproduced all three failure cases. Passed 17 focused checks, 170 affected tests and full discovery: 337 tests run, eight skipped. Existing ResourceWarning persists. Receipts: `runtime/tmp/l5-review5-*.txt`. Independent review and later acceptance gates remain pending.
<!-- /cwi:tests -->

CWI: ready
