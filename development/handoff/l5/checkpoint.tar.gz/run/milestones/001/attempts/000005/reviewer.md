One defect remains:

**[P2] Resume loses a previously observed timeout when the supervisor left no final result.** In [jobs.py:216](/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/20261113T063709_7f21ba4a/worktree/src/research_pipeline/jobs.py:216), forced reconciliation replaces the saved terminal state with `running`. After the newly tested cancellation race records `timed_out`, a later resume encounters the unfinished result and a collected service (`LoadState=not-found`). It then changes the outcome to `failed`, reports the command outcome unavailable, and overwrites the cleanup record containing the timeout evidence.

Preserve durable, previously observed outcomes while independently rechecking ownership and cleanup. Extend the new timeout-race regression through saved-state reconstruction and resume with the service absent; assert that `timed_out`, its supporting observation, original deadline, and partial outputs survive.

The settled-publication repair addresses the first finding. I read the complete revised diff and supporting evidence; I did not execute tests. Later L5 reopening, crash recovery, and native acceptance remain appropriately deferred for this milestone.

CWI: changes_requested
