Complete milestone diff: milestones/001/diffs/24fe9c92b015.diff
