<!-- cwi:decisions -->
Resume now preserves observed job outcomes and supporting evidence independently of current cleanup checks. The extended regression covers absent services/results and confirms foreign ownership still blocks cleanup. Updated the continuity report.
<!-- /cwi:decisions -->

<!-- cwi:tests -->
Passed 166 affected tests and 333 tests in full discovery; eight live/native gates remained disabled. An existing temporary-directory ResourceWarning persists.
<!-- /cwi:tests -->

CWI: ready
