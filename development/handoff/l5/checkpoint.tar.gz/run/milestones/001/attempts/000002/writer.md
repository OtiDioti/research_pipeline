<!-- cwi:decisions -->
Implemented L5-M1 owned STOP/pause resume with schema 8, ownership reconciliation, fresh quota preflight, safe marker rollback, and durable handoff/publication continuity.

COMPLETE reopening, general crash recovery and native scientific acceptance remain pending. Decisions and receipts are documented in `development/requests/v0-l5-continuity.md`.
<!-- /cwi:decisions -->

<!-- cwi:tests -->
Passed 218 focused regression tests and 331 tests in full discovery. Eight live/native gates remained disabled. Compilation passed.
<!-- /cwi:tests -->

CWI: ready
