<!-- cwi:decisions -->
Preserved verified timeout properties separately from final cleanup status. Cancellation and reconciliation retain timeout outcomes after unit collection or cleanup-observation failure; uncertain cleanup still holds capacity. Added real-cleanup-path regressions and updated the continuity report.
<!-- /cwi:decisions -->

<!-- cwi:tests -->
Reproduced both failures before repair. Passed 16 focused checks, 169 affected tests and full discovery: 336 tests run, eight skipped. Existing ResourceWarning persists. Receipts: `runtime/tmp/l5-review4-*.txt`. Independent review and later acceptance gates remain pending.
<!-- /cwi:tests -->

CWI: ready
