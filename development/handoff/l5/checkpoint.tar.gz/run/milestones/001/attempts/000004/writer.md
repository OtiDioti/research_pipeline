<!-- cwi:decisions -->
Fixed both findings: resume preserves settled job publication metadata, and cancellation recognizes observed service timeouts. Added regressions covering resumed finalization and timeout races. Updated the continuity report.
<!-- /cwi:decisions -->

<!-- cwi:tests -->
Passed 166 affected regression tests and 333 tests in full discovery. Eight live/native gates remained disabled.
<!-- /cwi:tests -->

CWI: ready
