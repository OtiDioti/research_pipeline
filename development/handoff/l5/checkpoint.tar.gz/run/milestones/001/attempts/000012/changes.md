Complete milestone diff: milestones/001/diffs/e845ce52574b.diff
