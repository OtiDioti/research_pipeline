<!-- cwi:decisions -->
Separated cancellation requests from supported outcomes. Rejected cleanup preserves uncertainty and capacity; later service absence cannot establish cancellation. Added restart regressions and updated the continuity report. Independent review and later L5 acceptance gates remain pending.
<!-- /cwi:decisions -->

<!-- cwi:tests -->
Reproduced the defect before repair. Passed five focused tests, 168 affected tests and full discovery: 335 tests run, eight skipped. Existing temporary-directory ResourceWarning persists. Receipts: `runtime/tmp/l5-review3-*.txt`.
<!-- /cwi:tests -->

CWI: ready
