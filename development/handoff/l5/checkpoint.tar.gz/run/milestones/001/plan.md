**Next milestone: L5-M1 — Owned explicit resume**

Implement explicit resume for current-format scientific STOP, quota STOP and confirmed pause. Preserve COMPLETE and reject its resumption until L5-M3. Crash states requiring additional recovery remain explicitly unsupported until L5-M2; refusal must preserve their artifacts and reservations.

**Inspected evidence and discoveries**

- Read `AGENTS.md`, `PROJECT.md`, the lifecycle amendment, `STATUS.md`, current usage/report documentation, affected runtime modules and relevant tests.
- The supplied baseline completed successfully: **308 tests, eight skipped**. Accepted L4 final/combined evidence had seven skipped because its native gate was enabled.
- `cli.main()` currently rejects `resume`; `Coordinator.initialize()` requires fresh operational state.
- `Coordinator.attach()` already reads native quota before creating a scientific thread. However, its admission block and terminal-state handling prevent direct reuse for stopped-state preflight.
- Publication baselines and predecessor lookup depend partly on `Coordinator.contexts`, which exists only in memory.
- `JobManager._reconcile()` distinguishes completion, timeout and cancellation, while `cancel()` and offline pause can overwrite an actual outcome with “cancelled.”
- Existing logical IDs, immutable documents, opponent history, quota policy and Linux ownership checks provide the foundation. Do not revive `checkpoint.py` or historical timed protocols.

**Files and interfaces**

| File | Required changes |
| --- | --- |
| `src/research_pipeline/cli.py` | Wire `resume PROJECT` into the existing foreground lifecycle under the project lock; keep failed preparation outside ordinary terminal finalization. |
| `src/research_pipeline/collaboration.py` | Add saved-state restoration, staged resume preparation/commit, durable predecessor reconstruction and successor intake continuity. |
| `src/research_pipeline/workspace.py` | Add narrowly scoped marker archival/removal helpers and persist required science baselines. Reuse existing atomic writes and safe reads. |
| `src/research_pipeline/jobs.py` | Reconcile saved outcomes before cancellation; preserve observed completion/timeout and require resumed owners to inspect retained jobs. |
| `src/research_pipeline/isolation.py` | Reconstruct and verify saved allocation membership and limits before reuse. Preserve existing ownership checks. |
| `src/research_pipeline/codex.py` | Explain prior STOP/pause, remaining blockers, recovery limitations and actual job outcomes in successor intake. |
| Tests | Add `tests/test_v0_l5.py`; extend existing ownership, quota and publication tests where behavior changes. |
| Documentation | Create `development/requests/v0-l5-continuity.md`; update README and affected `FOLDER_CONTENT.md` indexes to describe only delivered behavior. |

Keep the six MCP tools and existing `control(...)` signature. No new backend, controller service, dependency registry or migration layer is needed.

**1. Persist enough state for an actual restart**

Advance operational state to **schema 8** and reject older schemas clearly without modifying them. Update schema-dependent tests and documentation. All new tests create fresh supported state.

Persist:

- The backend executable/model selection, existing resource limits and secondary staleness interval.
- Each context’s science baseline and publication baseline, currently held in memory.
- Existing predecessor identities, immutable handoff references, input fingerprints and incorporation acknowledgements.
- A small continuation record containing attempt ID, source outcome, prior terminal explanation/references, prior quota record, preparation phase and actual failure/cleanup observations.

Retain the investigation `run_id`, logical task IDs, job IDs, opponent identity, review history, immutable documents and cumulative context usage. A resume attempt gets its own identifier; it does not create a new investigation or resource grant.

Reconstruct stopped context publication inputs from saved records and deterministic context directories. Do not reopen old authentication homes, RPC sockets or native threads. Change `science_intake()` and `finalize_publications()` so predecessor reasoning and pending publication also work without old in-memory context objects.

Current canonical Markdown must remain protected against predecessor drafts. Reading today’s files must not silently establish a new baseline that acknowledges an earlier unresolved human edit.

**2. Acquire ownership and reconcile before preparation**

Add a restoration entry point, such as `Coordinator.restore(project)`, called only while `workspace.acquire_project_lock()` is held. The same lock remains held throughout preparation and execution.

Resume must:

1. Load and validate supported state and the requested source outcome.
2. Reread authoritative questions, optional research `AGENTS.md`, feedback and reference authorization.
3. Check all recorded context/job ownership against actual services and cgroups, including records whose saved cleanup flag claims success.
4. Reconcile job results before stopping any remaining owned work.
5. Require confirmed quiescence before preparing replacements.

Reuse saved allocation slots only after checking actual aggregate/per-slot caps and membership. Recreate absent allocation slices only after predecessor cleanup is established. Do not silently alter limits or allocate a second parallel grant. `resume` inherits saved configuration; it has no cap-enlargement options.

For never-launched records, use the existing durable no-launch evidence. Missing ownership, mismatched invocation identity, changed boot identity or unavailable cleanup observations must retain reservations and prevent replacement admission. Do not signal a foreign invocation.

For this milestone, unsupported crash/failure states receive an explicit retained-state diagnostic. Do not route them through fresh initialization or delete their runtime directories.

**3. Prepare with fresh native quota while STOP remains intact**

Separate primary transport setup from scientific admission sufficiently to prepare a resumed primary without temporarily clearing the saved STOP.

Use one recorded primary preparation transport inside the existing slot:

- Start the existing isolated app-server with native file authentication.
- Read real account quota through the primary control path before creating a replacement scientific thread.
- Evaluate a fresh quota record using existing weekly-window, multiple-bucket, freshness and ordinary-usage rules.
- Require remaining weekly allowance **strictly above 15%**.
- Preserve the old latched cutoff as historical evidence; a successful explicit preflight may establish a new active quota record.
- Validate controlled MCP schemas and prepare current instructions/handoff intake before commit. Existing measured-intake/native-inventory checks still govern subsequent scientific tools.

Preparation must not run scientific turns, jobs, delegates or opposition. A quota reset alone performs no action.

Keep preparation quota observations separate from the old terminal latch so callbacks cannot overwrite its explanation or treat it as already cleared. Reuse the prepared transport after commit.

On any preparation failure, close that transport using cleanup-only handling. Do not invoke terminal writers that could replace the previous STOP. Report both the preparation failure and the preserved stopping reason. Unconfirmed preparation cleanup blocks another attempt.

**4. Commit marker clearing safely**

Archive the exact applicable STOP and acknowledgement bytes, hashes and terminal metadata before removing anything. Use a private attempt directory and a small preparation phase record; this is a finite file transaction, not event replay.

Commit sequence:

1. Persist successful preparation, including ownership reconciliation, fresh quota and intake fingerprints.
2. Recheck marker versions, intake versions and quota validity.
3. Remove the matching old acknowledgement, then STOP.
4. Persist the active continuation state and enable ordinary admission.
5. Start monitoring and runners through the existing foreground lifecycle.

No await should separate the final admission check from enabling execution.

If removal or persistence fails, keep admissions blocked, clean up the candidate and restore archived markers where possible. Preserve an explicit interrupted-preparation record if restoration cannot finish. A later explicit resume must reconcile that record before admitting anything; `help` and `inspect` remain read-only.

Refuse to remove unexpected or externally changed marker bytes. An absent acknowledgement never becomes an invented successful acknowledgement.

Archive prior terminal/quota fields before clearing active latches such as `stop_origin`, requested scientific intent and terminal commit metadata. Preserve historical errors and objections. Do not let an old final request finalize the resumed investigation again.

**5. Carry continuity into successors**

Successor intake must contain:

- The prior stopping reason, intervention request and continuation note paths.
- The exact validated predecessor handoff when available.
- Current instructions, questions, feedback and changed input paths.
- Reconciled job identities, commands, original deadlines, outcomes and retained output/checkpoint locations.
- Existing objections, attempts and opponent history.
- An explicit statement that resume does not establish that the previous blocker was solved.

Resolve immutable handoffs through `Documents.raw()` and verify their recorded hashes. A missing/unusable handoff must be reported without manufacturing a scientific summary. Preserve usable science and operational STOP notes; refuse admission when no safe continuation basis exists.

For resumed tasks, require inspection of retained job outcomes before replacement computations, including completed, cancelled and timed-out jobs. Do not limit this requirement to active jobs or the first summary page.

Preserve nonreleased tasks and their slots. Released delegates remain released. An idle opponent retains its identity and returns through the existing proposal path. Interrupted review cannot reuse stale authorization; changed bound inputs require renewed assessment.

**6. Preserve actual job outcomes**

Before cancellation, reconcile the supervisor result and service state. Recheck the retained result after stopping to handle completion racing cancellation.

Retain a supported completion before the original deadline as completed/failed according to its return code. Preserve observed expiry as timed out. Record cancellation only when cancellation is supported by the observed outcome. Missing results must retain an honest unknown/lost-outcome explanation.

Keep original deadlines, launch counts and partial outputs. Resume must never automatically relaunch a command or claim internal simulation continuation.

**Testable acceptance criteria**

- Help, inspect, rejected `start`, concurrent `resume`, unsupported state and failed preflight preserve STOP/ACK bytes and expose the original explanation.
- Quota preflight rejects exactly 15%, below reserve, missing/incomplete/stale weekly telemetry and denied ordinary usage. A successful explicit preflight uses a fresh observation; reset timestamps alone never launch work.
- Failure injection around marker removal/state persistence leaves admissions blocked and permits safe reconciliation of the preparation record.
- A newly constructed coordinator resumes saved state with fresh context/native-thread IDs while retaining investigation/task/job/opponent identities, accounting, handoffs and objection history.
- Ownership mismatch or cleanup uncertainty prevents all replacement admissions and retains capacity.
- Reconciliation preserves successful completion, timeout and partial outputs across restart and cancellation races.
- A canonical human edit made after stopping survives reconstruction and deferred publication; the existing exact-version incorporation mechanism remains required.
- Retained jobs beyond summary pagination cannot escape required inspection.
- COMPLETE remains unchanged and explicitly unsupported for reopening at this milestone.

Use existing service/backend doubles with clear engineering-fixture labels. Include a real local lock-contention check. Full process-crash evidence and native scientific continuity belong to later roadmap milestones.

The Writer should run focused L5 and affected L1–L4 regression modules, followed by ordinary unittest discovery. Keep native/live gates disabled here. Record actual commands and receipts; do not reuse the supplied baseline as evidence for new code.

**Delivery boundary**

The L5 report must distinguish this completed engineering increment from pending pause/crash, reopening and native acceptance. Record accepted L4 refs and final/combined receipts accurately while retaining historical failures. Update README with the supported resume behavior and remaining restrictions.

Do not modify manager-owned `STATUS.md`, human requirements, protected scientific inputs, historical receipts or the retained M5 branch/worktree. L5 acceptance remains pending until the later milestones, independent review and required trusted verification succeed.
