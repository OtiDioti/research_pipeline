# Recovery of unfinished work

Original objective: # V0-L5: resume, reopen and recover scientific continuity

## Objective and authority
Implement V0-L5 of the human-owned `2026-11-12-v0-context-lifecycle-design.md` after accepted L1–L4. Read that amendment, PROJECT.md, AGENTS.md and current STATUS.md; preserve human-owned requirements. The amendment supersedes older conflicting timers, context thresholds and reopening rules. L4 feature `2b9c61d08fcad1ea005afeaf3fc219da91e22e06` integrated at `3a23c695561f5c92ecd9c71c89da6d4c02114b4f`; fresh final and combined each passed 308 tests, seven disabled gates. Both native primary/opponent investigations reached acknowledged scientific COMPLETE with confirmed cleanup and unchanged protected inputs. Acceptance and exact receipts: `/home/francesco/Desktop/gits/research_project/research_pipeline/coding_pipeline/logs/manager/v0-l4-scientific-decisions-20261113T025828Z-9c0cb8e8/acceptance.json`. Resolve ordinary engineering questions autonomously.

## Broad approach and scope
Build on existing app-server execution, stable logical/task/job identities, immutable scientific evidence, measured 55% rollover, centralized 15% weekly reserve and L4 opposition/finalization. Use existing Python/Linux supervision, ordinary Markdown and small runtime records; replace superseded resume paths. The architect owns implementation boundaries and tool schemas. No legacy-state migration is required.

Explicit resume must acquire exclusive investigation ownership, reconcile actual agent/job ownership and perform prerequisites including real sufficient weekly quota before replacement admission or clearing STOP/acknowledgement. Preserve terminal explanations through help, inspect, concurrent-launch rejection and failed preflight. Carry handoffs, unresolved objections, attempts and actual job outcomes forward; resume does not assert a prior blocker was solved. Quota reset alone never starts research.

Reopen COMPLETE when authoritative questions, relevant evidence/documentation or human feedback changed, including corrective feedback with unchanged questions. Retain previous science and unaffected findings, highlight changed documents and implications in intake/status, and invalidate stale agreement. Clear markers safely after successful admission preparation; normal opposition and completion requirements apply anew. Unchanged relevant intake reports existing completion without repeating the investigation. Use lightweight version comparison plus scientific judgment, without a universal dependency/invalidation framework.

Reread current research questions, optional research AGENTS.md and feedback. Preserve and incorporate human Markdown edits through existing version-bound mechanisms at checkpoints and before publication. Starting evidence and human instructions remain read-only.

Pause must fully suspend all owned contexts, jobs and descendants with useful handoffs. Resume reconciles actual completion/cancellation/timeout outcomes and retained outputs before deciding whether to restart computations; never claim a killed simulation continued internally. Crash recovery must reconcile ownership/cleanup before replacement admission, prevent duplicate computations and unconstrained surviving agents, preserve independently enforced original job deadlines and cumulative accounting, and recover usable checkpoints. Report missing handoffs, uncertain cleanup and possibly lost progress honestly; uncertain ownership retains reservations.

Preserve isolation/native authentication, evidence-version binding, opponent history/authority and human grants. Defaults remain two agents sharing 2048 MiB, zero swap, 128 process/thread tasks and one concurrent job. No fixed investigation/session/demo work allowance, primary staleness watchdog or silent cap enlargement.

## Completion criteria and validation
- Consequential tests cover STOP preservation on failed/rejected launches; successful owned resume with preflight/handoff continuity; separate COMPLETE reopening cases for changed questions, new evidence/documentation and corrective feedback; unchanged completion; and human-edit preservation.
- Real local process pause/crash/restart checks establish actual cleanup, retained outcomes, independent timeouts, no duplicate admission and honest uncertain/lost-progress handling. Reuse existing checks when adequate.
- Demonstrate representative resumed scientific work through actual authorized native primary/opponent execution with public/test inputs. Add opt-in discovery gate `RESEARCH_PIPELINE_V0_L5_NATIVE=1`, reserving fresh private receipts under inherited `RESEARCH_PIPELINE_V0_L5_OUTPUT_DIR`. Enabled missing prerequisites fail visibly. Label engineering fixtures separately; never fabricate science, agreement or sufficient real quota. Operational test-bound expiry means failed/interrupted validation.
- Independent pipeline review and required final/combined verification pass. Keep accepted L1–L4 native gates and historical M1–M5 live gates disabled unless a concrete changed behavior requires repeating them.

The pipeline owns implementation, tests, review and demonstrations; the manager assesses reports without independently repeating product work. Reuse existing MCP dependencies via `PYTHONPATH=src:<current-root>/coding_pipeline/logs/20261111T063907_2732fff6/runtime/tmp/test-dependencies`. Trusted host final/combined stages inherit the authorized user bus and native file authentication. Restricted Writer bus failures do not authorize workarounds. Source review may proceed with trusted validation explicitly pending, without accepting L5 or waiving failed gates.

## Reporting, constraints and non-goals
Report decisions, actual commands/receipts, refs, live versus fixture evidence, cleanup, limitations and L6 dependency in `development/requests/v0-l5-continuity.md`; update README and relevant indexes. STATUS.md remains manager-owned. Align current documentation with accepted L4 evidence above, retaining historical failures accurately.

Follow AGENTS.md proportionality: existing libraries, direct files, reversible designs, demonstrated abstractions, realistic failures and consequential tests; remove superseded complexity where justified. Preserve PROJECT.md, AGENTS.md, the human amendment, all protected `research_example/starting_evidence/`, historical receipts and retained M5 branch `cwi/20261111T063907_2732fff6` at `1b70aea25f6c5f8496acdea12e9a27c6f3d4ecbd` and its worktree. Do not resume/reset/approve/merge that M5 run. No L6 integrated/M5 harness work, private M5 science, new database/broker/backend/controller, event replay, migrations, automatic quota-reset resume, remote actions or component-branch merges. Human scientific acceptance remains mandatory for M5.


Milestone 1; unfinished phase: reviewer.

Blocking question or failure:
Milestone repair budget exhausted.

User response:
Continue the same V0-L5 run from preserved partial work with another bounded repair attempt. The prior invocation exited 5 at failed / reviewer, milestone 1, turn 7, repair attempt 2; ownership-before-retry-001.json confirms the lock is unowned, no matching worker remains, and no L5 native receipt exists. Original request/config remain frozen and unchanged.

The latest independent review confirms that settled job publication and durable timeout preservation are addressed. The remaining P2 is a distinct evidence-boundary defect: cancellation records an observed cancelled outcome even when owned termination is unconfirmed and no authoritative final result exists; a later absent-service reconciliation then treats a rejected cancellation request as actual cancellation. Preserve and use the latest review and immutable attempt reports.

Before another local patch, reassess the small outcome-observation boundary: keep requested actions, actual supported outcomes, and current ownership/cleanup observations distinct. Preserve demonstrated publication and timeout fixes without layering special cases or expanding the platform. Unknown command outcomes must stay unknown when evidence cannot establish them; cleanup uncertainty and capacity retention remain binding. Reproduce the reviewer case through rejected cleanup followed by absent service/no final result, with no prior observed outcome. Repair through the existing Writer and require independent review and consequential regression checks. Do not waive review, native acceptance or final/combined verification; no manager product tests or source edits have been performed.

Continue the existing milestone roadmap after approval. Current authority, grants, models/efforts, isolation, protected inputs and non-goals are unchanged. No L6/private M5 work or component changes. The unsubmitted next-l6-request-draft.md is a future handoff only. Trust the current main STATUS.md for management state; do not modify it.

Continue the unfinished objective using existing source changes, decisions and reports. Inspect preserved work before changing it; do not assume any previous operation completed.
