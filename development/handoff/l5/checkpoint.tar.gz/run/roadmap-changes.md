## After milestone 1
M1 already implements substantial job-outcome reconciliation, deferred publication and checkpoint reconstruction. M2 should reuse these mechanisms.

Introduce the process-validation portion of `RESEARCH_PIPELINE_V0_L5_NATIVE=1` in M2 because production service cleanup needs trusted-host evidence. M4 will extend that gate with resumed native scientific execution. Process fixtures alone cannot establish scientific continuity or sufficient real quota.

