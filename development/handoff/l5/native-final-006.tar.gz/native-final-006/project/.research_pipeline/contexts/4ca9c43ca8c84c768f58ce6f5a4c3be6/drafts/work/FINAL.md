# Final scientific decision

## Reasons
Both questions are answered in the unchanged reviewed [proposal](PROPOSAL.md) and [derivation](CONTINUITY.md). For uniform n subdivisions, approximation-minus-integral error for x^2 is +1/(6n^2); the opposite convention reverses sign, and doubling n quarters error. Exact rational and floating computations corroborate this. For other fixed C^2 functions, |T-I|<=||f''||infinity/(12n^2) in exact arithmetic. Finite successful tests do not provide universal accuracy: fixed cos(64*pi*x) gives T=1 at n=8,16,32 although its integral is zero.

Primary [numerical report](document:36ecaab71d947d14ad23a2ab57c79cf164f35369b46679f2bc886782566d6bfb), [code](/project/work/check.py), [data](/project/work/data.json), [plan](PLAN.md), [status](../RESEARCH_STATUS.md), [handoff](../handoffs/primary.md).

## Response to challenge
Read the complete [independent review](document:c66aa4c72772dff6ac2b0694b2925123f6d751573db10b3e1ef4f7d10d7dd16e) through history/read_history, including all reasoning and limitations; next_offset was null. The review independently reconstructed the local error and checked n=1,2,3,5,7,10,31,100,257, with negative quadratic and affine controls. This addresses potential overreliance on dyadic tests and confirms that error sign is curvature dependent. The reviewer reproduced cosine aliasing; the ~1e-18 difference between residuals at n=128 is immaterial because neither residual is claimed to be a certified bound.

The independent polynomial p=product_{k=0}^4(x-k/4)^2 is zero at every n=2,4 node yet positive between nodes, so its integral is positive while both approximations vanish. This supplies an additional exact-arithmetic illustration of the limitation already stated, and is integrated as corroborating review evidence without changing the reviewed claims. The review reports its exact integral as 5/1419264 and records its coefficients. [Independent numerical report](document:4c20509f02b08452cda2f49b1371b8fc0b055a8e117e6ce23ef0780f98860ce3), [countercheck code](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/countercheck.py), [countercheck data](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/countercheck.json). These are the report and review's complete code/data dependencies. No objections were raised; exhaustive review agrees complete on the current version. Opponent released=true, idle with context null confirms retirement after delivery.

## Unfinished work
No unresolved scientific question or objection. No universal reliability probability, arbitrary-implementation validation, or floating error certificate is claimed.

## Continuation guidance
Reproduce using standard-library Python and the linked scripts in admitted jobs. New functions or a requested tolerance require function-specific derivative/resolution analysis and floating arithmetic assessment. Reopen with fresh review for changed questions or evidence.

## Decision record
{"version":"5b1cc302c81fef91dc9a3e4c45f3268933ace3599f003d78f69d0cf682b0b1e6","delegated_work":{"task-445686ad4c874e3385430177c35a17d7":{"disposition":"integrated","reason":"Read entire exhaustive review and independent numerical report; incorporated non-dyadic corroboration and exact polynomial illustration of the existing scope limitation. No objections; agrees complete and retirement confirmed."}}}
