# Completion proposal with corrected complex derivation

## Results
On uniform n>=1 subintervals of [0,1], define signed error E=T-I, approximation minus integral. For x^2, square summation gives T=1/3+1/(6n^2); independently, chord excess t(h-t) integrates to h^3/6 per panel, giving E=+1/(6n^2). Thus it is an overestimate, quartered on doubling n; I-T has the opposite sign. Fresh rational checks at n=3,7,31,100 and nine earlier checks corroborate the result.

For fixed C^2 f with |f''|<=M, integrating the interpolation bound M*t(h-t)/2 gives |T-I|<=M/(12n^2). This guarantees fixed-function convergence in exact arithmetic; it supplies no shared tolerance over all smooth functions.

For integer m>0, cos(2*pi*m*x) has I=0 and T=1 if n divides m, otherwise 0, by geometric summation. The fixed m=32 example gives wrong agreement at T=1 for n=8,16,32. At n=33 cancellation yields T=0, yet its samples coincide with a one-cycle cosine; accurate quadrature therefore does not identify waveform frequency. Zeros at n=64,128 likewise do not establish a universal resolution threshold.

For noninteger frequency nu, w=2*pi*nu and q=exp(i*w/n), q!=1, endpoint weighting gives S=[sum_{k=0}^{n-1}q^k+(q^n-1)/2]/n=(1-q^n)[1/(1-q)-1/2]/n. The bracket equals i*cot(w/(2*n))/2, so Re S=sin(w)*cot(w/(2*n))/(2*n)=I*z*cot(z), z=w/(2*n), I=sin(w)/w. This corrects the former intermediate numerator error. For q=1 use direct summation, not the singular quotient.

For nu=32.25, I=1/(64.5*pi)=0.00493503699509753. Errors at n=32,33,64,4096 are +0.6315568985, -0.2167809000, -0.0050309156, -1.0065287e-6. For fixed w, z*cot(z)=1-z^2/3+O(z^4) gives E=-I*w^2/(12n^2)+O(n^-4). Hence n^2 E tends to -w/12=-16.886060513... (observed -16.8867493 at n=4096). Eighteen new direct complex sums corroborate corrected complex and real formulas; maximum complex difference 9.420567836197387e-14.

A common-multiple integer frequency aliases to constant 1 on any finite chosen list of uniform meshes while I=0. Thus finite agreement cannot certify arbitrary smooth functions, and does not contradict fixed-function convergence. Known M and n>=sqrt(M/(12*epsilon)), rounded up with n>=1, suffice for exact-arithmetic absolute accuracy; sampled agreement does not determine M. Cancellation, waveform resolution and integration accuracy are distinct.

## Assumptions
Uniform integer n>=1; proofs assume exact arithmetic and samples. Fixed-w asymptotics require nu/n tending to zero and are not uniform over increasing-frequency families. Floating tolerances are observations, not certified rounding bounds. No universal points-per-cycle threshold, adaptive accuracy certificate, statistical reliability probability or arbitrary implementation validation is claimed.

## Evidence and reproduction
[Corrected derivation and preserved human clarification](/project/work/CONTINUITY.md), [plan](/project/work/PLAN.md), [status](/project/RESEARCH_STATUS.md), [new direct sign-check report](document:5717cbffb5be297abd71306597d6ddaad2151537c2428000664d30cdbce12bce), [sign code](/project/work/sign_check.py), [sign data](/project/work/sign_check_data.json), [frequency report](document:928a29295316bb610581ed6eabca805c06adc62a2e3c9feaa392a0148f76c035), [frequency code](/project/work/resolution_check.py), [frequency data](/project/work/resolution_data.json), [historical report](document:36ecaab71d947d14ad23a2ab57c79cf164f35369b46679f2bc886782566d6bfb), [historical code](/project/work/check.py), [historical data](/project/work/data.json). These explicitly include all local supporting artifacts and their Markdown dependencies. Reports were read fully. Run standard-library Python `python3 /project/work/sign_check.py` and `python3 /project/work/resolution_check.py` in admitted jobs. Fresh sign job 2022c77ad7b04630aad5063b10456afa completed return 0 with confirmed cleanup; prior frequency job c01c240862e3425d8734b1c329de339a also completed and cleaned. The sign job tested frequencies 0.25,17.125,32.25 and n=3,16,32,33,64,4096, excluding q=1; integer cases use separate exact reasoning.

## Reasons
Original Q1 and Q2 and human corrective feedback have analytical answers and reproducible computations. The independent review identified a localized supporting algebra error, now corrected with an explicit endpoint-weighted derivation and new numerical evidence. Main numerical values and scope verdict survive. Renewed independent agreement is required before completion.

## Recovery attempts
Inspected retained primary outcomes before fresh computations; all completed with confirmed cleanup. Read entire challenge for proposal 0964a06a00c94ce89a5d5ae441264016 via read_history, next_offset null, and entire opponent numerical snapshot. Accepted O1, reconstructed summation independently, corrected continuity, retained human clarification verbatim and renewed incorporate_edit acknowledgement at its exact canonical human hash. Ran a new admitted sign-check job and read its immutable report in full. No scientific blocker or STOP rationale exists.

## Unfinished work
Opponent reassessment of O1 and both questions on this exact corrected packet, full response to new challenge, and version-bound finalization after confirmed retirement.

## Continuation guidance
Keep frozen sources unchanged awaiting review. Read entire current challenge via history/read_history and fresh report. Retain O1 across phases; only opponent resolves its objection. Material new changes require another proposal. Finalize only after current exhaustive adequate agreement without open substantive objections and confirmed retirement.

## Responses to objections
O1: accepted and repaired by primary; formal opponent disposition remains open pending reassessment. The previous factor exp(i*w)-1 negated the complex trapezoid; correction to 1-exp(i*w) follows directly from finite geometric sum plus endpoint adjustment. Its real part now consistently yields +I*z*cot(z). New direct complex tests reproduce the sign error and support the corrected identity while preserving final real observations and asymptotics. No changed wider research program or numerical values were requested. This is an algebra correction, not a rounding explanation.

All three historical full reviews and adopted V2 assessment were read; no earlier objection IDs existed. The current needs_revision review was exhaustive: Q1 adequate; Q2 scope and feedback response supported, with O1 the only impediment. Its full reasoning is integrated rather than treating the verdict alone as evidence. Human frequency/resolution clarification remains explicitly incorporated.

## Decision record
{"coverage":[{"id":"Q1","question":"Signed composite trapezoidal error for x^2, convention, subdivision dependence and computation","disposition":"answered","explanation":"Square-sum and panel proofs give +1/(6n^2) for T-I; rational checks corroborate.","evidence":["work/CONTINUITY.md","work/resolution_check.py","work/resolution_data.json","document:928a29295316bb610581ed6eabca805c06adc62a2e3c9feaa392a0148f76c035"]},{"id":"Q2","question":"Reliability for other smooth functions and corrective frequency/resolution feedback","disposition":"answered","explanation":"C^2 bound proves fixed-function convergence; roots-of-unity and corrected noninteger geometric sums demonstrate finite sampling limits, cancellation and resolution distinction. O1 repaired in evidence, awaiting opponent confirmation.","evidence":["work/CONTINUITY.md","work/PLAN.md","RESEARCH_STATUS.md","work/sign_check.py","work/sign_check_data.json","document:5717cbffb5be297abd71306597d6ddaad2151537c2428000664d30cdbce12bce","document:928a29295316bb610581ed6eabca805c06adc62a2e3c9feaa392a0148f76c035"]}]}
