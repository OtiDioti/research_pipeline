# Scientific continuity

## Retained derivation
Uniform n>=1, h=1/n, T_n=h[(f(0)+f(1))/2+sum_{k=1}^{n-1}f(k/n)]. Define E=T-I, approximation minus integral. For x^2, I=1/3 and sum k^2=(n-1)n(2n-1)/6 give T=1/(2n)+(n-1)(2n-1)/(6n^2)=1/3+1/(6n^2). Thus E=+1/(6n^2), an overestimate quartered on doubling n. I-T reverses sign. Independently, the chord excess on [a,a+h] equals (x-a)(a+h-x); its integral h^3/6 summed over n panels gives the same result.

For fixed C^2 f with |f''|<=M, the interpolation bound M(x-a)(a+h-x)/2 integrates to |T-I|<=M/(12n^2). This proves fixed-function convergence in exact arithmetic, with no common M for the unrestricted smooth class. Sign depends on curvature; finite quadratic tests do not establish general accuracy or a statistical reliability probability.

## Human clarification (public test operator)

The earlier finite-resolution observations require a frequency/resolution
qualification. Reassess that assumption using an oscillatory example of your
choice; preserve applicable derivations and distinguish them from scope claims.

## Changed direction and implications
Current feedback calls for explicit frequency/resolution assessment while retaining applicable findings. Objectives unchanged. Historical completion and earlier agreements are history. The derivative bound and quadratic result survive; zeros on particular oscillatory meshes establish cancellation, not waveform resolution or a universal sampling threshold. Plan/status reflect this distinction. A later independent review found localized algebra error O1; its correction below leaves the real-valued conclusions unchanged.

## Corrected frequency analysis and O1 response
For integer m>0, cos(2*pi*m*x) has I=0. Endpoint periodicity makes T the real part of (1/n)sum_{k=0}^{n-1}exp(2*pi*i*m*k/n), equal to 1 if n divides m, otherwise 0. For m=32, n=8,16,32 agree at the wrong value 1. At n=33, T=0 but samples coincide with cos(2*pi*x), so accurate integration does not identify the frequency. Zeros at n=64,128 are likewise cancellation and cannot establish general resolution.

For noninteger frequency nu, set w=2*pi*nu, q=exp(i*w/n). For q!=1, the complex trapezoid is
S=[sum_{k=0}^{n-1}q^k+(q^n-1)/2]/n
 =(1-q^n)[1/(1-q)-1/2]/n.
Since q^n=exp(i*w) and the bracket equals i*cot(w/(2*n))/2, S=(1-exp(i*w))*i*cot(w/(2*n))/(2*n). Its real part is +sin(w)*cot(w/(2*n))/(2*n)=I*z*cot(z), where I=sin(w)/w and z=w/(2*n). If q=1, use the direct sum; the singular quotient is not evaluated.

The previous saved continuity used exp(i*w)-1 as the leading factor, which negated S. Reviewer O1 correctly challenged this supporting equality. The corrected numerator is 1-exp(i*w); the subsequent real formula and all previously reported values were correct. Primary accepts and repairs the error; O1 remains formally open until the opponent assesses the renewed packet. Full submitted review was read via history/read_history, next_offset null, and its full numerical report was read, next_offset null.

For nu=32.25, I=1/(64.5*pi)=0.00493503699509753. Observed E at n=32,33,64,128,4096 is respectively +0.6315568985, -0.2167809000, -0.0050309156, -0.0010764321, -1.0065287e-6. Expansion z*cot(z)=1-z^2/3+O(z^4) for fixed w as n tends to infinity gives E=-I*w^2/(12n^2)+O(n^-4); n^2 E tends to -w/12=-16.88606051304514 (observed -16.8867493 at n=4096). This expansion requires small nu/n and is not uniform over families with frequency increasing with n.

## Scope verdict and limitations
For any finite list of uniform grid counts, an integer m that is a common multiple gives cos(2*pi*m*x)=1 at every node but I=0. Thus agreement on finitely many uniform meshes cannot certify accuracy over arbitrary smooth functions. This family counterexample does not contradict convergence for any fixed member. For known M, n>=sqrt(M/(12*epsilon)), rounded up with n>=1, suffices for an exact-arithmetic absolute-error target. Unit-amplitude cosine permits M=w^2; this is sufficient and generally conservative. Sample agreement does not determine M. No universal points-per-cycle threshold, adaptive stopping certificate or arbitrary implementation validation is claimed. Floating phase evaluation, summation and rounding need separate error analysis; tolerances here are finite observations, not bounds.

## Evidence and reproduction
[Fresh direct sign-check report](document:5717cbffb5be297abd71306597d6ddaad2151537c2428000664d30cdbce12bce), [sign code](/project/work/sign_check.py), [sign data](/project/work/sign_check_data.json). Eighteen complex direct sums at frequencies 0.25,17.125,32.25 and n=3,16,32,33,64,4096 agree with corrected complex and final real formulas within 2e-12; largest complex difference 9.420567836197387e-14. Job 2022c77ad7b04630aad5063b10456afa completed return 0 with confirmed cleanup, original deadline 83766.493489973. Run python3 /project/work/sign_check.py with Python standard library.

[Frequency report](document:928a29295316bb610581ed6eabca805c06adc62a2e3c9feaa392a0148f76c035), [frequency code](/project/work/resolution_check.py), [frequency data](/project/work/resolution_data.json): four rational quadratic checks n=3,7,31,100 and 22 cosine checks passed. [Historical report](document:36ecaab71d947d14ad23a2ab57c79cf164f35369b46679f2bc886782566d6bfb), [historical code](/project/work/check.py), [historical data](/project/work/data.json): nine earlier rational checks and cosine aliasing. These derivations are self-contained. Fresh corrected packet requires renewed opposition; no current completion claimed.
