# Folder contents

- [contexts](contexts) — Supporting artifacts in contexts.
- [continuations](continuations) — Supporting artifacts in continuations.
- [documents](documents) — Supporting artifacts in documents.
- [jobs](jobs) — Supporting artifacts in jobs.
- [run.json](run.json) — Machine-readable run state, limits and observed outcomes.
- [run.lock](run.lock) — Exclusive foreground investigation lock.
