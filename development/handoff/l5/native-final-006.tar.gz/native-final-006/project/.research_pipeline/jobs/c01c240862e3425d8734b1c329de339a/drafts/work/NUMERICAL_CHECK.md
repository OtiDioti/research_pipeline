# Fresh frequency and resolution check

Reproduce with Python 3 standard library: `python3 /project/work/resolution_check.py`. [Code](/project/work/resolution_check.py), [data](/project/work/resolution_data.json). Four fresh exact rational quadratic checks passed. For integer frequency 32, T=1 for n=8,16,32 and near zero for all tested n not dividing 32, including n=33 (barely one point per cycle). For frequency 32.25 the integral is sin(64.5*pi)/(64.5*pi), approximately 0.004935. Uniform trapezoids agree with the analytic geometric-sum formula I*z*cot(z), z=pi*frequency/n, within 2e-12 on every tested grid. Near aliasing and eventual second-order errors are visible in the data. Formula comparison is a computational corroboration, not a floating error bound. Integer-frequency zero quadrature error can arise through cancellation without resolving the waveform. No universal sampling certificate follows from this finite experiment.

```json
{
  "quadratic": [
    {
      "n": 3,
      "T": "19/54",
      "error": "1/54"
    },
    {
      "n": 7,
      "T": "33/98",
      "error": "1/294"
    },
    {
      "n": 31,
      "T": "641/1922",
      "error": "1/5766"
    },
    {
      "n": 100,
      "T": "6667/20000",
      "error": "1/60000"
    }
  ],
  "oscillations": [
    {
      "frequency": 32.0,
      "n": 8,
      "points_per_cycle": 0.25,
      "T": 1.0,
      "integral": 0.0,
      "error": 1.0,
      "analytic_T": 1.0,
      "bound": 52.637890139143245,
      "scaled_error": 64.0
    },
    {
      "frequency": 32.0,
      "n": 16,
      "points_per_cycle": 0.5,
      "T": 1.0,
      "integral": 0.0,
      "error": 1.0,
      "analytic_T": 1.0,
      "bound": 13.159472534785811,
      "scaled_error": 256.0
    },
    {
      "frequency": 32.0,
      "n": 32,
      "points_per_cycle": 1.0,
      "T": 1.0,
      "integral": 0.0,
      "error": 1.0,
      "analytic_T": 1.0,
      "bound": 3.289868133696453,
      "scaled_error": 1024.0
    },
    {
      "frequency": 32.0,
      "n": 33,
      "points_per_cycle": 1.03125,
      "T": 1.204423766108503e-15,
      "integral": 0.0,
      "error": 1.204423766108503e-15,
      "analytic_T": 0.0,
      "bound": 3.0935031854041943,
      "scaled_error": 1.31161748129216e-12
    },
    {
      "frequency": 32.0,
      "n": 63,
      "points_per_cycle": 1.96875,
      "T": -4.0531951692664444e-16,
      "integral": 0.0,
      "error": -4.0531951692664444e-16,
      "analytic_T": 0.0,
      "bound": 0.8487843207118084,
      "scaled_error": -1.6087131626818518e-12
    },
    {
      "frequency": 32.0,
      "n": 64,
      "points_per_cycle": 2.0,
      "T": 0.0,
      "integral": 0.0,
      "error": 0.0,
      "analytic_T": 0.0,
      "bound": 0.8224670334241132,
      "scaled_error": 0.0
    },
    {
      "frequency": 32.0,
      "n": 128,
      "points_per_cycle": 4.0,
      "T": 3.720981855970251e-16,
      "integral": 0.0,
      "error": 3.720981855970251e-16,
      "analytic_T": 0.0,
      "bound": 0.2056167583560283,
      "scaled_error": 6.0964566728216596e-12
    },
    {
      "frequency": 32.0,
      "n": 256,
      "points_per_cycle": 8.0,
      "T": -1.682681771697503e-16,
      "integral": 0.0,
      "error": -1.682681771697503e-16,
      "analytic_T": 0.0,
      "bound": 0.051404189589007075,
      "scaled_error": -1.1027623258996755e-11
    },
    {
      "frequency": 32.0,
      "n": 512,
      "points_per_cycle": 16.0,
      "T": 8.500145032286355e-17,
      "integral": 0.0,
      "error": 8.500145032286355e-17,
      "analytic_T": 0.0,
      "bound": 0.012851047397251769,
      "scaled_error": 2.2282620193436742e-11
    },
    {
      "frequency": 32.0,
      "n": 1024,
      "points_per_cycle": 32.0,
      "T": -6.396792817664476e-17,
      "integral": 0.0,
      "error": -6.396792817664476e-17,
      "analytic_T": 0.0,
      "bound": 0.003212761849312942,
      "scaled_error": -6.707523425575346e-11
    },
    {
      "frequency": 32.0,
      "n": 4096,
      "points_per_cycle": 128.0,
      "T": -9.248244531301353e-17,
      "integral": 0.0,
      "error": -9.248244531301353e-17,
      "analytic_T": 0.0,
      "bound": 0.0002007976155820589,
      "scaled_error": -1.5515979612246156e-09
    },
    {
      "frequency": 32.25,
      "n": 8,
      "points_per_cycle": 0.24806201550387597,
      "T": 0.6345731492255569,
      "integral": 0.00493503699509753,
      "error": 0.6296381122304593,
      "analytic_T": 0.6345731492255591,
      "bound": 53.46356993441666,
      "scaled_error": 40.296839182749395
    },
    {
      "frequency": 32.25,
      "n": 16,
      "points_per_cycle": 0.49612403100775193,
      "T": 0.6361083632808537,
      "integral": 0.00493503699509753,
      "error": 0.6311733262857562,
      "analytic_T": 0.636108363280855,
      "bound": 13.365892483604165,
      "scaled_error": 161.58037152915358
    },
    {
      "frequency": 32.25,
      "n": 32,
      "points_per_cycle": 0.9922480620155039,
      "T": 0.6364919355013071,
      "integral": 0.00493503699509753,
      "error": 0.6315568985062096,
      "analytic_T": 0.6364919355013069,
      "bound": 3.3414731209010413,
      "scaled_error": 646.7142640703586
    },
    {
      "frequency": 32.25,
      "n": 33,
      "points_per_cycle": 1.0232558139534884,
      "T": -0.2118458629561468,
      "integral": 0.00493503699509753,
      "error": -0.21678089995124433,
      "analytic_T": -0.21184586295614738,
      "bound": 3.1420279851264157,
      "scaled_error": -236.07440004690508
    },
    {
      "frequency": 32.25,
      "n": 63,
      "points_per_cycle": 1.9534883720930232,
      "T": -0.00029696317505579193,
      "integral": 0.00493503699509753,
      "error": -0.005232000170153322,
      "analytic_T": -0.0002969631750559059,
      "bound": 0.8620983814065675,
      "scaled_error": -20.765808675338533
    },
    {
      "frequency": 32.25,
      "n": 64,
      "points_per_cycle": 1.9844961240310077,
      "T": -9.587861234005082e-05,
      "integral": 0.00493503699509753,
      "error": -0.005030915607437581,
      "analytic_T": -9.587861234036071e-05,
      "bound": 0.8353682802252603,
      "scaled_error": -20.60663032806433
    },
    {
      "frequency": 32.25,
      "n": 128,
      "points_per_cycle": 3.9689922480620154,
      "T": 0.0038586048494201495,
      "integral": 0.00493503699509753,
      "error": -0.0010764321456773803,
      "analytic_T": 0.0038586048494200355,
      "bound": 0.20884207005631508,
      "scaled_error": -17.6362642747782
    },
    {
      "frequency": 32.25,
      "n": 256,
      "points_per_cycle": 7.937984496124031,
      "T": 0.004674644864482805,
      "integral": 0.00493503699509753,
      "error": -0.0002603921306147247,
      "analytic_T": 0.004674644864482687,
      "bound": 0.05221051751407877,
      "scaled_error": -17.065058671966597
    },
    {
      "frequency": 32.25,
      "n": 512,
      "points_per_cycle": 15.875968992248062,
      "T": 0.004870452999082415,
      "integral": 0.00493503699509753,
      "error": -6.4583996015115e-05,
      "analytic_T": 0.004870452999082469,
      "bound": 0.013052629378519693,
      "scaled_error": -16.930307051386308
    },
    {
      "frequency": 32.25,
      "n": 1024,
      "points_per_cycle": 31.751937984496124,
      "T": 0.004918922673224526,
      "integral": 0.00493503699509753,
      "error": -1.6114321873004177e-05,
      "analytic_T": 0.0049189226732246055,
      "bound": 0.003263157344629923,
      "scaled_error": -16.897091172307228
    },
    {
      "frequency": 32.25,
      "n": 4096,
      "points_per_cycle": 127.0077519379845,
      "T": 0.004934030466402475,
      "integral": 0.00493503699509753,
      "error": -1.0065286950551935e-06,
      "analytic_T": 0.004934030466402507,
      "bound": 0.0002039473340393702,
      "scaled_error": -16.886749327139114
    }
  ]
}
```
