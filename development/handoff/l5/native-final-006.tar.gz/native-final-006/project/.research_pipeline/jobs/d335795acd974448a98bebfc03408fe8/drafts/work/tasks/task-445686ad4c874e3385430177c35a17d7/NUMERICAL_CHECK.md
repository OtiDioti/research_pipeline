# Fresh corrected-packet countercheck

Reproduce with Python standard library: `python3 /project/work/tasks/task-445686ad4c874e3385430177c35a17d7/corrected_countercheck.py`. [Code](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/corrected_countercheck.py), [data](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/corrected_countercheck.json).

Four exact rational quadratic checks passed. Fifteen independent panelwise complex sums agree with corrected geometric identity and real formula within 1e-11. Frequencies and meshes differ from primary suite. Integer aliasing reproduced. Common multiple 120 hides oscillation on grids 3,5,8 analytically. Tests are observations, not rounding certificates or universal resolution guarantees.

{
  "quadratic": [
    {
      "n": 2,
      "error": "1/24"
    },
    {
      "n": 7,
      "error": "1/294"
    },
    {
      "n": 19,
      "error": "1/2166"
    },
    {
      "n": 61,
      "error": "1/22326"
    }
  ],
  "complex": [
    {
      "nu": 0.375,
      "n": 5,
      "T": 0.29453117131057016,
      "error": -0.005574267408465228,
      "complex_discrepancy": 1.2412670766236366e-16
    },
    {
      "nu": 0.375,
      "n": 16,
      "T": 0.299562898486578,
      "error": -0.0005425402324573669,
      "complex_discrepancy": 2.482534153247273e-16
    },
    {
      "nu": 0.375,
      "n": 33,
      "T": 0.29997793468792283,
      "error": -0.00012750403111255748,
      "complex_discrepancy": 3.1401849173675503e-16
    },
    {
      "nu": 0.375,
      "n": 128,
      "T": 0.30009696454447987,
      "error": -8.474174555517244e-06,
      "complex_discrepancy": 1.2225062931717345e-15
    },
    {
      "nu": 0.375,
      "n": 2048,
      "T": 0.30010540561697713,
      "error": -3.310205826112522e-08,
      "complex_discrepancy": 9.722695338554405e-15
    },
    {
      "nu": 17.125,
      "n": 5,
      "T": 0.016976131856441166,
      "error": 0.010404479913688567,
      "complex_discrepancy": 1.429055260297166e-15
    },
    {
      "nu": 17.125,
      "n": 16,
      "T": 0.0984027965899511,
      "error": 0.0918311446471985,
      "complex_discrepancy": 7.961605949470553e-16
    },
    {
      "nu": 17.125,
      "n": 33,
      "T": -0.000638219312571888,
      "error": -0.007209871255324489,
      "complex_discrepancy": 3.4866699951436855e-16
    },
    {
      "nu": 17.125,
      "n": 128,
      "T": 0.006180031080365671,
      "error": -0.00039162086238692974,
      "complex_discrepancy": 3.066430433449947e-16
    },
    {
      "nu": 17.125,
      "n": 2048,
      "T": 0.00657014021258143,
      "error": -1.5117301711701017e-06,
      "complex_discrepancy": 3.801578323111275e-17
    },
    {
      "nu": 32.25,
      "n": 5,
      "T": 0.015838444032455046,
      "error": 0.010903407037357517,
      "complex_discrepancy": 1.4453276276477136e-15
    },
    {
      "nu": 32.25,
      "n": 16,
      "T": 0.6361083632808536,
      "error": 0.6311733262857561,
      "complex_discrepancy": 1.7377739072730912e-15
    },
    {
      "nu": 32.25,
      "n": 33,
      "T": -0.21184586295614677,
      "error": -0.2167808999512443,
      "complex_discrepancy": 8.441528768080325e-16
    },
    {
      "nu": 32.25,
      "n": 128,
      "T": 0.003858604849420148,
      "error": -0.001076432145677382,
      "complex_discrepancy": 1.3793506212950068e-16
    },
    {
      "nu": 32.25,
      "n": 2048,
      "T": 0.004931010387524671,
      "error": -4.026607572859067e-06,
      "complex_discrepancy": 7.196489415735149e-17
    }
  ],
  "alias": [
    {
      "n": 8,
      "T": 1.0
    },
    {
      "n": 16,
      "T": 1.0
    },
    {
      "n": 32,
      "T": 1.0
    },
    {
      "n": 33,
      "T": 1.2385925618474403e-15
    },
    {
      "n": 64,
      "T": 0.0
    }
  ],
  "common_multiple": 120
}