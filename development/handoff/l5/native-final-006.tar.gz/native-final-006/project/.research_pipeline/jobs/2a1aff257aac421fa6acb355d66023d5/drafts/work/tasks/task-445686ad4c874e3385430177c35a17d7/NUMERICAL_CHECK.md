# Fresh version-3 numerical countercheck

Reproduce with Python standard library: `python3 /project/work/tasks/task-445686ad4c874e3385430177c35a17d7/recheck_v3.py`. [Code](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/recheck_v3.py); [data](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/recheck_v3.json).

Six exact quadratic/sign/quartering checks passed. Polynomial 30*x^2*(1-x)^2 has exact integral 1 and T1=0. Cosine aliasing reproduced at n=8,16,32. Float residuals are observations, not bounds. Finite tests cannot certify arbitrary smooth functions.

{
  "quadratic": [
    {
      "n": 2,
      "error": "1/24"
    },
    {
      "n": 5,
      "error": "1/150"
    },
    {
      "n": 9,
      "error": "1/486"
    },
    {
      "n": 17,
      "error": "1/1734"
    },
    {
      "n": 37,
      "error": "1/8214"
    },
    {
      "n": 113,
      "error": "1/76614"
    }
  ],
  "polynomial": {
    "formula": "30*x^2*(1-x)^2",
    "integral": "1",
    "T1": "0",
    "T2": "15/16"
  },
  "cosine": [
    {
      "n": 8,
      "T": 1.0
    },
    {
      "n": 16,
      "T": 1.0
    },
    {
      "n": 32,
      "T": 1.0
    },
    {
      "n": 33,
      "T": 1.1842378929335002e-15
    },
    {
      "n": 64,
      "T": 0.0
    },
    {
      "n": 128,
      "T": 3.7730235602495554e-16
    }
  ]
}