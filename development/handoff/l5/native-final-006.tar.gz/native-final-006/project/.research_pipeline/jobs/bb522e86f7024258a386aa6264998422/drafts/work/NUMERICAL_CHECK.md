# Numerical check

Run `python3 /project/work/check.py` with Python 3 standard library. Code: [check.py](/project/work/check.py); data: [data.json](/project/work/data.json).

Uniform composite trapezoids for x^2: all nine exact Fraction checks passed for n=1,2,4,8,16,32,64,128,1024 against T-1/3=1/(6n^2). Floating scaled errors follow 1/6, subject to cancellation.

For fixed smooth f(x)=cos(64*pi*x), exact integral is zero. At n=8,16,32 every sample is exactly 1 in real arithmetic, so T=1; at n=64,128 exact T=0 by cosine cancellation. Floating observations follow below. This is aliasing; it refutes universal accuracy and refinement-based confidence from a few smooth tests, not convergence for a fixed C^2 function.

```json
{
  "quadratic": [
    {
      "n": 1,
      "exact_T": "1/2",
      "exact_error": "1/6",
      "float_T": 0.5,
      "float_error": 0.16666666666666669,
      "scaled_error": 0.16666666666666669
    },
    {
      "n": 2,
      "exact_T": "3/8",
      "exact_error": "1/24",
      "float_T": 0.375,
      "float_error": 0.041666666666666685,
      "scaled_error": 0.16666666666666674
    },
    {
      "n": 4,
      "exact_T": "11/32",
      "exact_error": "1/96",
      "float_T": 0.34375,
      "float_error": 0.010416666666666685,
      "scaled_error": 0.16666666666666696
    },
    {
      "n": 8,
      "exact_T": "43/128",
      "exact_error": "1/384",
      "float_T": 0.3359375,
      "float_error": 0.002604166666666685,
      "scaled_error": 0.16666666666666785
    },
    {
      "n": 16,
      "exact_T": "171/512",
      "exact_error": "1/1536",
      "float_T": 0.333984375,
      "float_error": 0.0006510416666666852,
      "scaled_error": 0.1666666666666714
    },
    {
      "n": 32,
      "exact_T": "683/2048",
      "exact_error": "1/6144",
      "float_T": 0.33349609375,
      "float_error": 0.00016276041666668517,
      "scaled_error": 0.16666666666668561
    },
    {
      "n": 64,
      "exact_T": "2731/8192",
      "exact_error": "1/24576",
      "float_T": 0.3333740234375,
      "float_error": 4.069010416668517e-05,
      "scaled_error": 0.16666666666674246
    },
    {
      "n": 128,
      "exact_T": "10923/32768",
      "exact_error": "1/98304",
      "float_T": 0.333343505859375,
      "float_error": 1.017252604168517e-05,
      "scaled_error": 0.16666666666696983
    },
    {
      "n": 1024,
      "exact_T": "699051/2097152",
      "exact_error": "1/6291456",
      "float_T": 0.33333349227905273,
      "float_error": 1.5894571941954538e-07,
      "scaled_error": 0.16666666668606922
    }
  ],
  "stress": [
    {
      "m": 32,
      "n": 8,
      "T": 1.0,
      "integral": 0,
      "error": 1.0
    },
    {
      "m": 32,
      "n": 16,
      "T": 1.0,
      "integral": 0,
      "error": 1.0
    },
    {
      "m": 32,
      "n": 32,
      "T": 1.0,
      "integral": 0,
      "error": 1.0
    },
    {
      "m": 32,
      "n": 64,
      "T": 0.0,
      "integral": 0,
      "error": 0.0
    },
    {
      "m": 32,
      "n": 128,
      "T": 3.720981855970251e-16,
      "integral": 0,
      "error": 3.720981855970251e-16
    }
  ]
}
```
