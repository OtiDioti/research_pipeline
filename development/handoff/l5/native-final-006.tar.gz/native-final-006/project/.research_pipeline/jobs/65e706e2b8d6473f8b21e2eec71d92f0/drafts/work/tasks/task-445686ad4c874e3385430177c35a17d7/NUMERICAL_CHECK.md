# Independent numerical check

Run `python3 /project/work/tasks/task-445686ad4c874e3385430177c35a17d7/countercheck.py` using standard-library Python. [Code](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/countercheck.py); [data](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/countercheck.json).

Nine exact rational quadratic checks including non-dyadic grids passed; negative quadratic and affine controls passed. Cosine aliasing reproduced. The additional polynomial is the squared product of x-k/4 for k=0,...,4: nonnegative, positive between nodes, smooth, and invisible to n=2,4. Its exact positive integral and zero sampled approximations independently disprove accuracy certification by smoothness and successive agreement. These finite checks support the stated claims only; analytic proofs establish general scope, and floating cosine residuals are not rigorous bounds.

```json
{
  "quadratic": [
    {
      "n": 1,
      "T": "1/2",
      "error": "1/6"
    },
    {
      "n": 2,
      "T": "3/8",
      "error": "1/24"
    },
    {
      "n": 3,
      "T": "19/54",
      "error": "1/54"
    },
    {
      "n": 5,
      "T": "17/50",
      "error": "1/150"
    },
    {
      "n": 7,
      "T": "33/98",
      "error": "1/294"
    },
    {
      "n": 10,
      "T": "67/200",
      "error": "1/600"
    },
    {
      "n": 31,
      "T": "641/1922",
      "error": "1/5766"
    },
    {
      "n": 100,
      "T": "6667/20000",
      "error": "1/60000"
    },
    {
      "n": 257,
      "T": "44033/132098",
      "error": "1/396294"
    }
  ],
  "cosine": [
    {
      "n": 8,
      "T": 1.0
    },
    {
      "n": 16,
      "T": 1.0
    },
    {
      "n": 32,
      "T": 1.0
    },
    {
      "n": 33,
      "T": 1.1954413153825172e-15
    },
    {
      "n": 64,
      "T": 0.0
    },
    {
      "n": 128,
      "T": 3.703634621210483e-16
    }
  ],
  "polynomial": {
    "coefficients": [
      "0",
      "0",
      "9/1024",
      "-75/512",
      "1045/1024",
      "-995/256",
      "2273/256",
      "-25/2",
      "85/8",
      "-5",
      "1"
    ],
    "integral": "5/1419264",
    "T2": "0",
    "T4": "0",
    "T8": "6525/2147483648"
  }
}
```
