# Current-phase numerical countercheck

Reproduce: `python3 /project/work/tasks/task-445686ad4c874e3385430177c35a17d7/recheck_v2.py` (Python standard library). [Code](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/recheck_v2.py); [data](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/recheck_v2.json).

Six exact quadratic checks and exact doubling/sign controls passed. A fresh polynomial product over k=0,...,6 of (x-k/6)^2 has positive exact integral but T3=T6=0. Dividing by its exact integral yields error -1 with identical successive trapezoids. This finite stress case establishes failure of universal refinement certification; it does not refute fixed-function convergence. Cosine results reproduce the proposed aliasing; floating residuals are observations, not error bounds.

```json
{
  "quadratic": [
    {
      "n": 1,
      "T": "1/2",
      "error": "1/6"
    },
    {
      "n": 3,
      "T": "19/54",
      "error": "1/54"
    },
    {
      "n": 6,
      "T": "73/216",
      "error": "1/216"
    },
    {
      "n": 11,
      "T": "81/242",
      "error": "1/726"
    },
    {
      "n": 29,
      "T": "561/1682",
      "error": "1/5046"
    },
    {
      "n": 101,
      "T": "6801/20402",
      "error": "1/61206"
    }
  ],
  "polynomial": {
    "coefficients": [
      "0",
      "0",
      "25/104976",
      "-245/34992",
      "37849/419904",
      "-23569/34992",
      "685307/209952",
      "-126455/11664",
      "1184153/46656",
      "-18277/432",
      "21581/432",
      "-245/6",
      "791/36",
      "-7",
      "1"
    ],
    "integral": "7/360277632",
    "T3": "0",
    "T6": "0",
    "scaled_integral": "1",
    "scaled_T3": "0",
    "scaled_T6": "0"
  },
  "cosine": [
    {
      "n": 8,
      "T": 1.0
    },
    {
      "n": 16,
      "T": 1.0
    },
    {
      "n": 32,
      "T": 1.0
    },
    {
      "n": 33,
      "T": 1.1954413153825172e-15
    },
    {
      "n": 64,
      "T": 0.0
    },
    {
      "n": 128,
      "T": 3.703634621210483e-16
    }
  ]
}
```
