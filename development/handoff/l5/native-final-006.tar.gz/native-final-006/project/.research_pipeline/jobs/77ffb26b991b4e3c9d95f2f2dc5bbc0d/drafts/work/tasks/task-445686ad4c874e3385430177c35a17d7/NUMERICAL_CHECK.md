# Independent reassessment numerical check

Reproduce: `python3 /project/work/tasks/task-445686ad4c874e3385430177c35a17d7/reassessment_countercheck.py` using Python standard library. [Code](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/reassessment_countercheck.py), [data](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/reassessment_countercheck.json).

Four exact quadratic checks pass. Independent panelwise complex exponential sums agree with (1-exp(i*w))*(1/(1-exp(i*w/n))-1/2)/n within 1e-12 for tested nonsingular cases. The continuity expression with exp(i*w)-1 is its negative. Final real formula I*z*cot(z) agrees with sums. Integer aliasing and noninteger near-alias sensitivity reproduced; frequency 17.125 adds an independent control. Floating tolerances are observations, not rigorous arithmetic bounds.

{
  "quadratic": [
    {
      "n": 1,
      "error": "1/6"
    },
    {
      "n": 4,
      "error": "1/96"
    },
    {
      "n": 13,
      "error": "1/1014"
    },
    {
      "n": 53,
      "error": "1/16854"
    }
  ],
  "oscillatory": [
    {
      "frequency": 32,
      "n": 16,
      "T": 1.0,
      "imag": -4.8070481769716555e-15,
      "integral": 0,
      "error": 1.0,
      "scaled_error": 256.0,
      "correct_complex_real": 1.0,
      "printed_complex_real": null
    },
    {
      "frequency": 32,
      "n": 32,
      "T": 1.0,
      "imag": -4.5850035720466234e-15,
      "integral": 0,
      "error": 1.0,
      "scaled_error": 1024.0,
      "correct_complex_real": 1.0,
      "printed_complex_real": null
    },
    {
      "frequency": 32,
      "n": 33,
      "T": 1.2385925618474403e-15,
      "imag": -4.852888924045118e-16,
      "integral": 0,
      "error": 1.2385925618474403e-15,
      "scaled_error": 1.3488272998518624e-12,
      "correct_complex_real": 1.2436442678668671e-15,
      "printed_complex_real": -1.2436442678668671e-15
    },
    {
      "frequency": 32,
      "n": 64,
      "T": 0.0,
      "imag": -2.7755575615628914e-16,
      "integral": 0,
      "error": 0.0,
      "scaled_error": 0.0,
      "correct_complex_real": -3.749399456654644e-33,
      "printed_complex_real": 3.749399456654644e-33
    },
    {
      "frequency": 32,
      "n": 128,
      "T": 3.725318664660193e-16,
      "imag": -1.3877787807814457e-16,
      "integral": 0,
      "error": 3.725318664660193e-16,
      "scaled_error": 6.103562100179261e-12,
      "correct_complex_real": -3.0616169978683836e-17,
      "printed_complex_real": 3.0616169978683836e-17
    },
    {
      "frequency": 32,
      "n": 1024,
      "T": -6.635317295611287e-17,
      "imag": -3.6144589925235504e-17,
      "integral": 0,
      "error": -6.635317295611287e-17,
      "scaled_error": -6.957634468562901e-11,
      "correct_complex_real": -3.885639880119651e-17,
      "printed_complex_real": 3.885639880119651e-17
    },
    {
      "frequency": 32,
      "n": 4096,
      "T": -9.115429765171879e-17,
      "imag": -3.757522857314802e-17,
      "integral": 0,
      "error": -9.115429765171879e-17,
      "scaled_error": -1.5293153410311788e-09,
      "correct_complex_real": -3.8973890574738625e-17,
      "printed_complex_real": 3.8973890574738625e-17
    },
    {
      "frequency": 32.25,
      "n": 16,
      "T": 0.6361083632808536,
      "imag": 0.6361083632808471,
      "integral": 0.00493503699509753,
      "error": 0.6311733262857561,
      "scaled_error": 161.58037152915355,
      "correct_complex_real": 0.6361083632808552,
      "printed_complex_real": -0.6361083632808552
    },
    {
      "frequency": 32.25,
      "n": 32,
      "T": 0.636491935501307,
      "imag": 0.6364919355012987,
      "integral": 0.00493503699509753,
      "error": 0.6315568985062094,
      "scaled_error": 646.7142640703585,
      "correct_complex_real": 0.6364919355013071,
      "printed_complex_real": -0.6364919355013071
    },
    {
      "frequency": 32.25,
      "n": 33,
      "T": -0.21184586295614677,
      "imag": -0.211845862956144,
      "integral": 0.00493503699509753,
      "error": -0.2167808999512443,
      "scaled_error": -236.07440004690505,
      "correct_complex_real": -0.21184586295614735,
      "printed_complex_real": 0.21184586295614735
    },
    {
      "frequency": 32.25,
      "n": 64,
      "T": -9.587861234005183e-05,
      "imag": -9.587861234035212e-05,
      "integral": 0.00493503699509753,
      "error": -0.0050309156074375815,
      "scaled_error": -20.606630328064334,
      "correct_complex_real": -9.587861234036071e-05,
      "printed_complex_real": 9.587861234036071e-05
    },
    {
      "frequency": 32.25,
      "n": 128,
      "T": 0.003858604849420148,
      "imag": 0.003858604849419904,
      "integral": 0.00493503699509753,
      "error": -0.001076432145677382,
      "scaled_error": -17.636264274778227,
      "correct_complex_real": 0.003858604849420036,
      "printed_complex_real": -0.003858604849420036
    },
    {
      "frequency": 32.25,
      "n": 1024,
      "T": 0.004918922673224517,
      "imag": 0.0049189226732245135,
      "integral": 0.00493503699509753,
      "error": -1.611432187301285e-05,
      "scaled_error": -16.897091172316323,
      "correct_complex_real": 0.004918922673224605,
      "printed_complex_real": -0.004918922673224605
    },
    {
      "frequency": 32.25,
      "n": 4096,
      "T": 0.004934030466402482,
      "imag": 0.0049340304664024235,
      "integral": 0.00493503699509753,
      "error": -1.0065286950482547e-06,
      "scaled_error": -16.8867493270227,
      "correct_complex_real": 0.0049340304664025085,
      "printed_complex_real": -0.0049340304664025085
    },
    {
      "frequency": 17.125,
      "n": 16,
      "T": 0.0984027965899511,
      "imag": 0.040759772922999565,
      "integral": 0.0065716519427526,
      "error": 0.0918311446471985,
      "scaled_error": 23.508773029682818,
      "correct_complex_real": 0.0984027965899515,
      "printed_complex_real": -0.0984027965899515
    },
    {
      "frequency": 17.125,
      "n": 32,
      "T": -0.0012252603954518069,
      "imag": -0.0005075194732342869,
      "integral": 0.0065716519427526,
      "error": -0.007796912338204407,
      "scaled_error": -7.9840382343213125,
      "correct_complex_real": -0.001225260395451506,
      "printed_complex_real": 0.001225260395451506
    },
    {
      "frequency": 17.125,
      "n": 33,
      "T": -0.000638219312571888,
      "imag": -0.0002643590950355409,
      "integral": 0.0065716519427526,
      "error": -0.007209871255324489,
      "scaled_error": -7.851549797048368,
      "correct_complex_real": -0.0006382193125721164,
      "printed_complex_real": 0.0006382193125721164
    },
    {
      "frequency": 17.125,
      "n": 64,
      "T": 0.004945507429588336,
      "imag": 0.002048496250152884,
      "integral": 0.0065716519427526,
      "error": -0.001626144513164264,
      "scaled_error": -6.660687925920826,
      "correct_complex_real": 0.00494550742958841,
      "printed_complex_real": -0.00494550742958841
    },
    {
      "frequency": 17.125,
      "n": 128,
      "T": 0.006180031080365671,
      "imag": 0.0025598526893750207,
      "integral": 0.0065716519427526,
      "error": -0.00039162086238692974,
      "scaled_error": -6.416316209347457,
      "correct_complex_real": 0.006180031080365675,
      "printed_complex_real": -0.006180031080365675
    },
    {
      "frequency": 17.125,
      "n": 1024,
      "T": 0.006565604187257238,
      "imag": 0.002719562299535569,
      "integral": 0.0065716519427526,
      "error": -6.047755495361927e-06,
      "scaled_error": -6.341531266304628,
      "correct_complex_real": 0.006565604187257266,
      "printed_complex_real": -0.006565604187257266
    },
    {
      "frequency": 17.125,
      "n": 4096,
      "T": 0.006571274023250517,
      "imag": 0.002721910822500331,
      "integral": 0.0065716519427526,
      "error": -3.7791950208317104e-07,
      "scaled_error": -6.340437117061811,
      "correct_complex_real": 0.006571274023250518,
      "printed_complex_real": -0.006571274023250518
    }
  ]
}