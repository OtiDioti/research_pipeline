This small public investigation exercises the scientific
decision path. Supply your own reasoning and conclusions; no expected answer or
verdict is supplied. Use the default allocation. No delegation is needed.

Primary: derive the result, run an admitted numerical computation, preserve
reproducible code/data and qualified conclusions with explicit evidence links.
Save a usable handoff. When results justify a terminal proposal, use the ordinary
propose_complete/propose_stop controls. Read the opponent's entire challenge
(the full text, regardless of its verdict) with control(history) and
control(read_history, parent="review"), following next_offset until null.
Respond substantively in saved Markdown, correct or investigate objections and
present renewed proposals whenever needed. Preserve objection dispositions.
After a delivered review and confirmed opponent retirement, only you may request
finalize_complete/finalize_stop with the current proposal version. Do not change
frozen supporting artifacts while awaiting review; new science requires a renewed
proposal. Scientific STOP requires your actual best recovery attempts and need for
human intervention; a test's operational bound is never a scientific rationale.

Opponent: inspect the EXACT current frozen packet via control(check/tasks).
Independently reconstruct consequential claims and run your own admitted numerical
countercheck or reproduction in your scoped workspace. Save the code, data,
claim-specific reasoning and limitations as evidence. Challenge both the signed
error and generalization to other smooth functions. Do not manufacture an error
or agreement. Use submit_review for your own assessment of all questions, with
the current version. Retain every prior objection ID/disposition and review phase
in your handoff. When linking frozen evidence, include its local Markdown
dependencies explicitly, as required by packet freezing.

Both roles: have your actual numerical job write its report in its PRIVATE JOB
DRAFT BATCH at /run/research-drafts/<task-workspace>/NUMERICAL_CHECK.md,
creating parent directories first. For the primary, that exact job-side path is
/run/research-drafts/work/NUMERICAL_CHECK.md. The opponent substitutes its full
project-relative task workspace from control(tasks). Do not write the report
directly under /project: only the job draft batch yields the required immutable
job snapshot after confirmed cleanup. Write executable code/data under your
/project task workspace, and use explicit /project links to them in the report.
The report contains the job's numerical observations and reproduction instructions.
Link that report and its code/data explicitly from your proposal/review and handoff.
This procedural filename helps the engineering observer distinguish a numerical
job from read-only inspection; all findings, parameters, code and assessments
are yours to supply.
Job-written Markdown can remain a private retained draft while your context is
active. Discover/read its immutable snapshot with control(documents/read_document).
Link the report using a Markdown link whose target is the document: prefix followed
by its actual 64-character document ID. Include its code/data dependencies
explicitly in the proposal/review. Handoffs must also use that document link when
the report is not yet canonical, or save the exact report with write_draft first.
Use write_draft for other scientific Markdown, job_run/job_wait for actual
computations and read-only inspection, and explicit evidence links. End ordinary
turns when appropriate; normal turn completion is not a terminal decision.
No exchange count or elapsed test time establishes scientific completion.


Continuity procedure, applying on every scientific phase: primary maintains
work/CONTINUITY.md with substantive findings, assumptions, evidence and remaining
limitations, and links it explicitly from the proposal and handoff. Maintain
work/PLAN.md and RESEARCH_STATUS.md with scientific direction and implications.
On explicit resume, read the supplied predecessor handoff, retained job outcomes,
current HUMAN_FEEDBACK.md and canonical work/CONTINUITY.md. Inspect prior science
before choosing new work. Incorporate current human corrections in your reasoning;
retain the labelled human clarification verbatim in your revised continuity note.
Save the revised note with write_draft, then use control(incorporate_edit,
path="work/CONTINUITY.md", sha256=<exact current canonical human version hash>)
before publication. Explain changed direction and implications in that note, the
plan and research status, retaining unaffected findings. Each role must perform
new analytical reasoning and a new admitted numerical check for the current
phase, with a fresh job-side NUMERICAL_CHECK.md snapshot explicitly linked in the
new proposal/review. Earlier numerical jobs alone cannot establish reassessment.
No procedural instruction supplies a scientific conclusion or terminal verdict.
