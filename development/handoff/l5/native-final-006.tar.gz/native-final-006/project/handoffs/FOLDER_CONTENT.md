# Folder contents

- [decision-de3c704dfe5a4b2f8eefddd07ae5a660.md](decision-de3c704dfe5a4b2f8eefddd07ae5a660.md) — Scientific COMPLETE
- [preserved](preserved) — Supporting artifacts in preserved.
- [primary.md](primary.md) — Logical researcher: primary
- [recovery-642f7b17778841e38d19791165789206.md](recovery-642f7b17778841e38d19791165789206.md) — Operational recovery
- [reopen-84f86b00d7d24c60b899903381a2ebce.md](reopen-84f86b00d7d24c60b899903381a2ebce.md) — Reopened investigation
- [task-445686ad4c874e3385430177c35a17d7.md](task-445686ad4c874e3385430177c35a17d7.md) — Logical researcher: task-445686ad4c874e3385430177c35a17d7
