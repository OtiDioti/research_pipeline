from pathlib import Path
from fractions import Fraction as F
import math,json
quad=[]
for n in [3,7,31,100]:
 t=(F(1,2)+sum((F(k,n)**2 for k in range(1,n)),F(0)))/n
 assert t-F(1,3)==F(1,6*n*n)
 quad.append(dict(n=n,T=str(t),error=str(t-F(1,3))))
rows=[]
for frequency in [32.0,32.25]:
 for n in [8,16,32,33,63,64,128,256,512,1024,4096]:
  w=2*math.pi*frequency
  t=(0.5*(1+math.cos(w))+math.fsum(math.cos(w*k/n) for k in range(1,n)))/n
  integral=0.0 if frequency.is_integer() else math.sin(w)/w
  expected=(1.0 if int(frequency)%n==0 else 0.0) if frequency.is_integer() else integral*(w/(2*n))/math.tan(w/(2*n))
  assert abs(t-expected)<2e-12
  rows.append(dict(frequency=frequency,n=n,points_per_cycle=n/frequency,T=t,integral=integral,error=t-integral,analytic_T=expected,bound=w*w/(12*n*n),scaled_error=n*n*(t-integral)))
data=dict(quadratic=quad,oscillations=rows)
Path('/project/work/resolution_data.json').write_text(json.dumps(data,indent=2)+'\n')
r=Path('/run/research-drafts/work/NUMERICAL_CHECK.md');r.parent.mkdir(parents=True,exist_ok=True)
r.write_text('# Fresh frequency and resolution check\n\nReproduce with Python 3 standard library: `python3 /project/work/resolution_check.py`. [Code](/project/work/resolution_check.py), [data](/project/work/resolution_data.json). Four fresh exact rational quadratic checks passed. For integer frequency 32, T=1 for n=8,16,32 and near zero for all tested n not dividing 32, including n=33 (barely one point per cycle). For frequency 32.25 the integral is sin(64.5*pi)/(64.5*pi), approximately 0.004935. Uniform trapezoids agree with the analytic geometric-sum formula I*z*cot(z), z=pi*frequency/n, within 2e-12 on every tested grid. Near aliasing and eventual second-order errors are visible in the data. Formula comparison is a computational corroboration, not a floating error bound. Integer-frequency zero quadrature error can arise through cancellation without resolving the waveform. No universal sampling certificate follows from this finite experiment.\n\n```json\n'+json.dumps(data,indent=2)+'\n```\n')
for row in rows:
 if row['frequency']==32.25: print(row['n'],row['T'],row['error'],row['scaled_error'])
