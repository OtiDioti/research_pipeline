# Scientific continuity

## Findings and derivation
Let n>=1 be the number of equal subintervals, h=1/n, and T_n=h[(f(0)+f(1))/2+sum_{k=1}^{n-1}f(k/n)]. Define signed error E_n=T_n-I (approximation minus exact integral). For f=x^2, I=1/3 and sum k^2=(n-1)n(2n-1)/6 gives T_n=1/(2n)+(n-1)(2n-1)/(6n^2)=1/3+1/(6n^2). Thus E_n=+1/(6n^2), an overestimate, exactly quartered when n doubles. The opposite convention I-T_n gives -1/(6n^2).

Independently, on a panel [a,a+h], its linear interpolant L satisfies L(x)-x^2=(x-a)(a+h-x). Integration gives h^3/6; summing n panels gives 1/(6n^2).

## Scope and justified bound
For any fixed f in C^2[0,1], the interpolation remainder implies |L(x)-f(x)|<=M(x-a)(a+h-x)/2 when |f''|<=M. Integrating and summing gives |T_n-I|<=M/(12n^2). Thus convergence follows analytically for each fixed C^2 function. Smoothness alone supplies no common finite M across all functions and no universal finite-grid accuracy. Sign is tied to curvature: -x^2 reverses it; affine functions are exact. The quadratic computation corroborates this implementation on those inputs, not all smooth functions or floating-point regimes.

For fixed analytic f(x)=cos(64*pi*x), I=0. For n=8,16,32 all sample phases are integer multiples of 2*pi and T_n=1, despite identical successive refinements. At n=64 alternating samples cancel, and at n=128 four-cycle samples cancel; T_n=0 in exact arithmetic. More generally a frequency m divisible by every tested n aliases identically. This does not contradict convergence for fixed f: its M=(64*pi)^2 is large, and finer resolved meshes converge. Scaling f also defeats a universal absolute error tolerance. Finite checks do not establish a probability of reliability or a rigorous adaptive stopping rule.

## Evidence
[Immutable numerical report](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/inputs/659445b8b13e4d238cb1407d2e90906d/files/documents/36ecaab71d947d14ad23a2ab57c79cf164f35369b46679f2bc886782566d6bfb.md), [code](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/inputs/659445b8b13e4d238cb1407d2e90906d/files/work/check.py), [data](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/inputs/659445b8b13e4d238cb1407d2e90906d/files/work/data.json). Nine exact rational quadratic checks passed; scaled floating errors ranged from 0.16666666666666669 to 0.16666666668606922. Cosine values were 1,1,1,0,3.720981855970251e-16 at n=8,16,32,64,128. Run `python3 /project/work/check.py` using standard library. Rational checks corroborate exact finite cases, while the derivation covers all positive integers. Floating residuals include rounding/cancellation and are not error bounds.

## Current inputs and limitations
No distinct human feedback supplied, no previous saved science found in inspected paths. Numerical job bb522e86f7024258a386aa6264998422 completed with cleanup confirmed. Independent opposition pending; no scientific terminal decision yet. No external references needed: all claims are derived here. No changes to objectives or incorporated human edits.
