# Folder contents

- [REVIEW_V3.md](REVIEW_V3.md) — Independent review of current proposal
- [recheck_v3.json](recheck_v3.json) — json artifact (754 bytes).
- [recheck_v3.py](recheck_v3.py) — py artifact (1790 bytes).
