from fractions import Fraction as F
from pathlib import Path
import math,json
w=Path(__file__).resolve().parent
def trap(f,n):
 return sum((f(F(k,n))+f(F(k+1,n)))/ (2*n) for k in range(n))
q=[]
for n in [1,2,3,5,7,10,31,100,257]:
 t=trap(lambda x:x*x,n); e=t-F(1,3)
 assert e==F(1,6*n*n)
 assert trap(lambda x:-x*x,n)+F(1,3)==-e
 assert trap(lambda x:3*x+2,n)==F(7,2)
 q.append(dict(n=n,T=str(t),error=str(e)))
cos=[]
for n in [8,16,32,33,64,128]:
 t=math.fsum((math.cos(64*math.pi*k/n)+math.cos(64*math.pi*(k+1)/n))/(2*n) for k in range(n))
 cos.append(dict(n=n,T=t))
# Squared product over all nodes of n=2 and n=4; hence both rules give zero.
p=[F(1)]
for r in [F(k,4) for k in range(5)]:
 for _ in range(2):
  z=[F(0)]*(len(p)+1)
  for j,a in enumerate(p): z[j]-=r*a; z[j+1]+=a
  p=z
def poly(x):
 v=F(0)
 for a in reversed(p):v=v*x+a
 return v
integral=sum((a/F(j+1) for j,a in enumerate(p)),F(0))
assert integral>0
assert trap(poly,2)==trap(poly,4)==0
out=dict(quadratic=q,cosine=cos,polynomial=dict(coefficients=[str(a) for a in p],integral=str(integral),T2=str(trap(poly,2)),T4=str(trap(poly,4)),T8=str(trap(poly,8))))
(w/'countercheck.json').write_text(json.dumps(out,indent=2))
r=Path('/run/research-drafts/work/tasks/task-445686ad4c874e3385430177c35a17d7/NUMERICAL_CHECK.md');r.parent.mkdir(parents=True,exist_ok=True)
r.write_text('# Independent numerical check\n\nRun `python3 '+str(w/'countercheck.py')+'` using standard-library Python. [Code]('+str(w/'countercheck.py')+'); [data]('+str(w/'countercheck.json')+').\n\nNine exact rational quadratic checks including non-dyadic grids passed; negative quadratic and affine controls passed. Cosine aliasing reproduced. The additional polynomial is the squared product of x-k/4 for k=0,...,4: nonnegative, positive between nodes, smooth, and invisible to n=2,4. Its exact positive integral and zero sampled approximations independently disprove accuracy certification by smoothness and successive agreement. These finite checks support the stated claims only; analytic proofs establish general scope, and floating cosine residuals are not rigorous bounds.\n\n```json\n'+json.dumps(out,indent=2)+'\n```\n')
print(json.dumps(out))
