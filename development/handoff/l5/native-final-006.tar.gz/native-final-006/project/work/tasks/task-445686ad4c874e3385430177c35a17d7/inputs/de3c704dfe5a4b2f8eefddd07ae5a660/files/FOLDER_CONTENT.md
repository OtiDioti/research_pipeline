# Folder contents

- [AGENTS.md](AGENTS.md) — Human-owned project instructions (read-only).
- [RESEARCH_STATUS.md](RESEARCH_STATUS.md) — Operational state and links to current scientific progress.
- [documents](documents) — Supporting artifacts in documents.
- [starting_evidence](starting_evidence) — Human-owned scientific inputs (read-only; questions and supplied evidence).
- [work](work) — Scientific plan, derivations, executable scripts and computation data.
