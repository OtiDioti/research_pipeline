from fractions import Fraction as F
from pathlib import Path
import json, math
w=Path(__file__).resolve().parent
def trap(f,n):
 return sum((f(F(k,n))+f(F(k+1,n)))*F(1,2*n) for k in range(n))
rows=[]
for n in [1,3,6,11,29,101]:
 t=trap(lambda x:x*x,n)
 assert t-F(1,3)==F(1,6*n*n)
 assert (trap(lambda x:x*x,2*n)-F(1,3))*4==t-F(1,3)
 assert trap(lambda x:-x*x,n)+F(1,3)==-F(1,6*n*n)
 rows.append(dict(n=n,T=str(t),error=str(t-F(1,3))))
# Different polynomial from previous phase: vanishes on all n=3 and n=6 nodes.
p=[F(1)]
for k in range(7):
 for _ in range(2):
  z=[F(0)]*(len(p)+1)
  for j,a in enumerate(p):z[j]-=F(k,6)*a;z[j+1]+=a
  p=z
def f(x):
 v=F(0)
 for a in reversed(p):v=v*x+a
 return v
I=sum((a/F(j+1) for j,a in enumerate(p)),F(0))
assert I>0 and trap(f,3)==trap(f,6)==0
stress=dict(coefficients=list(map(str,p)),integral=str(I),T3=str(trap(f,3)),T6=str(trap(f,6)),scaled_integral='1',scaled_T3='0',scaled_T6='0')
cos=[dict(n=n,T=math.fsum((math.cos(64*math.pi*k/n)+math.cos(64*math.pi*(k+1)/n))/(2*n) for k in range(n))) for n in [8,16,32,33,64,128]]
out=dict(quadratic=rows,polynomial=stress,cosine=cos)
(w/'recheck_v2.json').write_text(json.dumps(out,indent=2))
r=Path('/run/research-drafts/work/tasks/task-445686ad4c874e3385430177c35a17d7/NUMERICAL_CHECK.md');r.parent.mkdir(parents=True,exist_ok=True)
r.write_text('# Current-phase numerical countercheck\n\nReproduce: `python3 '+str(w/'recheck_v2.py')+'` (Python standard library). [Code]('+str(w/'recheck_v2.py')+'); [data]('+str(w/'recheck_v2.json')+').\n\nSix exact quadratic checks and exact doubling/sign controls passed. A fresh polynomial product over k=0,...,6 of (x-k/6)^2 has positive exact integral but T3=T6=0. Dividing by its exact integral yields error -1 with identical successive trapezoids. This finite stress case establishes failure of universal refinement certification; it does not refute fixed-function convergence. Cosine results reproduce the proposed aliasing; floating residuals are observations, not error bounds.\n\n```json\n'+json.dumps(out,indent=2)+'\n```\n')
print(json.dumps(out))
