from pathlib import Path
from fractions import Fraction as F
import math, cmath, json
w=Path(__file__).resolve().parent
q=[]
for n in [1,4,13,53]:
 t=sum((F(k,n)**2+F(k+1,n)**2)*F(1,2*n) for k in range(n))
 e=t-F(1,3)
 assert e==F(1,6*n*n)
 q.append(dict(n=n,error=str(e)))
rows=[]
for nu in [32,32.25,17.125]:
 for n in [16,32,33,64,128,1024,4096]:
  omega=2*math.pi*nu
  s=sum((cmath.exp(1j*omega*k/n)+cmath.exp(1j*omega*(k+1)/n))/(2*n) for k in range(n))
  I=0 if nu==32 else math.sin(omega)/omega
  if nu==32 and 32%n==0:
   correct=1+0j; printed=None
  else:
   bracket=1/(1-cmath.exp(1j*omega/n))-0.5
   correct=(1-cmath.exp(1j*omega))*bracket/n
   printed=(cmath.exp(1j*omega)-1)*bracket/n
   assert abs(s-correct)<1e-12
  real= (1 if 32%n==0 else 0) if nu==32 else I*(omega/(2*n))/math.tan(omega/(2*n))
  assert abs(s.real-real)<1e-12
  rows.append(dict(frequency=nu,n=n,T=s.real,imag=s.imag,integral=I,error=s.real-I,scaled_error=n*n*(s.real-I),correct_complex_real=correct.real,printed_complex_real=None if printed is None else printed.real))
out=dict(quadratic=q,oscillatory=rows)
(w/'reassessment_countercheck.json').write_text(json.dumps(out,indent=2))
r=Path('/run/research-drafts/work/tasks/task-445686ad4c874e3385430177c35a17d7/NUMERICAL_CHECK.md');r.parent.mkdir(parents=True,exist_ok=True)
report='# Independent reassessment numerical check\n\nReproduce: `python3 '+str(w/'reassessment_countercheck.py')+'` using Python standard library. [Code]('+str(w/'reassessment_countercheck.py')+'), [data]('+str(w/'reassessment_countercheck.json')+').\n\nFour exact quadratic checks pass. Independent panelwise complex exponential sums agree with (1-exp(i*w))*(1/(1-exp(i*w/n))-1/2)/n within 1e-12 for tested nonsingular cases. The continuity expression with exp(i*w)-1 is its negative. Final real formula I*z*cot(z) agrees with sums. Integer aliasing and noninteger near-alias sensitivity reproduced; frequency 17.125 adds an independent control. Floating tolerances are observations, not rigorous arithmetic bounds.\n\n'
r.write_text(report+json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
