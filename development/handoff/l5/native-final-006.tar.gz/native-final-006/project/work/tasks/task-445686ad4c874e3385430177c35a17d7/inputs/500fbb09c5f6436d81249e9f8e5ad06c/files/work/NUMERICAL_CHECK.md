# Direct complex sign correction check

Run `python3 /project/work/sign_check.py` using Python 3 standard library. [Code](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/inputs/500fbb09c5f6436d81249e9f8e5ad06c/files/work/sign_check.py), [data](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/inputs/500fbb09c5f6436d81249e9f8e5ad06c/files/work/sign_check_data.json). Eighteen direct endpoint-weighted complex sums agree with corrected formula (1-exp(i*w))*(1/(1-exp(i*w/n))-1/2)/n and final real formula I*z*cot(z) within 2e-12. The previous leading factor gives the negative. This corroborates the O1 repair; finite tolerances are observations, not rigorous arithmetic bounds. Frequencies 0.25,17.125,32.25 and n=3,16,32,33,64,4096 avoid q=1. Integer singular cases remain handled by the roots-of-unity argument.

```json
[
  {
    "nu": 0.25,
    "n": 3,
    "direct_real": 0.6220084679281462,
    "direct_imag": 0.6220084679281462,
    "correct_real": 0.6220084679281463,
    "correct_imag": 0.6220084679281462,
    "wrong_real": -0.6220084679281463,
    "complex_difference": 1.1102230246251565e-16
  },
  {
    "nu": 0.25,
    "n": 16,
    "direct_real": 0.6361083632808496,
    "direct_imag": 0.6361083632808495,
    "correct_real": 0.6361083632808494,
    "correct_imag": 0.6361083632808497,
    "wrong_real": -0.6361083632808494,
    "complex_difference": 3.1401849173675503e-16
  },
  {
    "nu": 0.25,
    "n": 32,
    "direct_real": 0.6364919355013015,
    "direct_imag": 0.6364919355013016,
    "correct_real": 0.6364919355013015,
    "correct_imag": 0.6364919355013016,
    "wrong_real": -0.6364919355013015,
    "complex_difference": 0.0
  },
  {
    "nu": 0.25,
    "n": 33,
    "direct_real": 0.6364995660891014,
    "direct_imag": 0.6364995660891013,
    "correct_real": 0.6364995660891016,
    "correct_imag": 0.6364995660891012,
    "wrong_real": -0.6364995660891016,
    "complex_difference": 2.482534153247273e-16
  },
  {
    "nu": 0.25,
    "n": 64,
    "direct_real": 0.636587814113642,
    "direct_imag": 0.6365878141136421,
    "correct_real": 0.6365878141136412,
    "correct_imag": 0.6365878141136426,
    "wrong_real": -0.6365878141136412,
    "complex_difference": 9.550499576785472e-16
  },
  {
    "nu": 0.25,
    "n": 4096,
    "direct_real": 0.6366197645653501,
    "direct_imag": 0.6366197645653529,
    "correct_real": 0.6366197645652836,
    "correct_imag": 0.6366197645654196,
    "wrong_real": -0.6366197645652836,
    "complex_difference": 9.420567836197387e-14
  },
  {
    "nu": 17.125,
    "n": 3,
    "direct_real": -0.09043035276456195,
    "direct_imag": -0.03745747856526641,
    "correct_real": -0.09043035276456211,
    "correct_imag": -0.037457478565264955,
    "wrong_real": 0.09043035276456211,
    "complex_difference": 1.4666530451630691e-15
  },
  {
    "nu": 17.125,
    "n": 16,
    "direct_real": 0.0984027965899511,
    "direct_imag": 0.04075977292299958,
    "correct_real": 0.0984027965899515,
    "correct_imag": 0.04075977292299888,
    "wrong_real": -0.0984027965899515,
    "complex_difference": 8.081652011750576e-16
  },
  {
    "nu": 17.125,
    "n": 32,
    "direct_real": -0.001225260395451809,
    "direct_imag": -0.0005075194732342865,
    "correct_real": -0.001225260395451506,
    "correct_imag": -0.0005075194732346356,
    "wrong_real": 0.001225260395451506,
    "complex_difference": 4.623587251470846e-16
  },
  {
    "nu": 17.125,
    "n": 33,
    "direct_real": -0.0006382193125718813,
    "direct_imag": -0.0002643590950355436,
    "correct_real": -0.0006382193125721164,
    "correct_imag": -0.0002643590950358043,
    "wrong_real": 0.0006382193125721164,
    "complex_difference": 3.510177873281364e-16
  },
  {
    "nu": 17.125,
    "n": 64,
    "direct_real": 0.004945507429588342,
    "direct_imag": 0.0020484962501528814,
    "correct_real": 0.00494550742958841,
    "correct_imag": 0.0020484962501524247,
    "wrong_real": -0.00494550742958841,
    "complex_difference": 4.616501785833114e-16
  },
  {
    "nu": 17.125,
    "n": 4096,
    "direct_real": 0.00657127402325051,
    "direct_imag": 0.002721910822500335,
    "correct_real": 0.006571274023250518,
    "correct_imag": 0.0027219108225003687,
    "wrong_real": -0.006571274023250518,
    "complex_difference": 3.4716146790954134e-17
  },
  {
    "nu": 32.25,
    "n": 3,
    "direct_real": -0.16666666666666594,
    "direct_imag": -0.16666666666666374,
    "correct_real": -0.16666666666666594,
    "correct_imag": -0.16666666666666372,
    "wrong_real": 0.16666666666666594,
    "complex_difference": 2.7755575615628914e-17
  },
  {
    "nu": 32.25,
    "n": 16,
    "direct_real": 0.6361083632808537,
    "direct_imag": 0.6361083632808471,
    "correct_real": 0.6361083632808552,
    "correct_imag": 0.6361083632808463,
    "wrong_real": -0.6361083632808552,
    "complex_difference": 1.6392246515987586e-15
  },
  {
    "nu": 32.25,
    "n": 32,
    "direct_real": 0.6364919355013071,
    "direct_imag": 0.6364919355012987,
    "correct_real": 0.6364919355013071,
    "correct_imag": 0.6364919355012985,
    "wrong_real": -0.6364919355013071,
    "complex_difference": 2.220446049250313e-16
  },
  {
    "nu": 32.25,
    "n": 33,
    "direct_real": -0.21184586295614685,
    "direct_imag": -0.21184586295614402,
    "correct_real": -0.21184586295614735,
    "correct_imag": -0.2118458629561446,
    "wrong_real": 0.21184586295614735,
    "complex_difference": 7.676812899781355e-16
  },
  {
    "nu": 32.25,
    "n": 64,
    "direct_real": -9.587861234005082e-05,
    "direct_imag": -9.587861234035266e-05,
    "correct_real": -9.587861234036071e-05,
    "correct_imag": -9.587861234035945e-05,
    "wrong_real": 9.587861234036071e-05,
    "complex_difference": 3.0996646034304956e-16
  },
  {
    "nu": 32.25,
    "n": 4096,
    "direct_real": 0.004934030466402465,
    "direct_imag": 0.004934030466402469,
    "correct_real": 0.0049340304664025085,
    "correct_imag": 0.004934030466402442,
    "wrong_real": -0.0049340304664025085,
    "complex_difference": 5.1027120307199386e-17
  }
]
```
