# Folder contents

- [REVIEW.md](REVIEW.md) — Current independent review
- [REVIEW_V2.md](REVIEW_V2.md) — Independent reassessment of current proposal
- [countercheck.json](countercheck.json) — json artifact (1286 bytes).
- [countercheck.py](countercheck.py) — py artifact (2188 bytes).
- [recheck_v2.json](recheck_v2.json) — json artifact (1219 bytes).
- [recheck_v2.py](recheck_v2.py) — py artifact (2085 bytes).
