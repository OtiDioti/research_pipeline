# Folder contents

- [NOTES.md](NOTES.md) — Review intake
- [REVIEW.md](REVIEW.md) — Independent review of proposal ce022a17604b409c9ff4e694c7552374
- [countercheck.json](countercheck.json) — json artifact (1286 bytes).
- [countercheck.py](countercheck.py) — py artifact (2188 bytes).
