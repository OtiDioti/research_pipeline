from pathlib import Path
from fractions import Fraction as F
import math,cmath,json
w=Path(__file__).resolve().parent
quadratic=[]
for n in [2,7,19,61]:
 t=sum((F(k,n)**2+F(k+1,n)**2)/(2*n) for k in range(n))
 assert t-F(1,3)==F(1,6*n*n)
 quadratic.append(dict(n=n,error=str(t-F(1,3))))
rows=[]
for nu in [0.375,17.125,32.25]:
 for n in [5,16,33,128,2048]:
  a=2*math.pi*nu
  direct=sum((cmath.exp(1j*a*k/n)+cmath.exp(1j*a*(k+1)/n))/(2*n) for k in range(n))
  q=cmath.exp(1j*a/n)
  formula=(1-cmath.exp(1j*a))*(1/(1-q)-0.5)/n
  integral=math.sin(a)/a
  assert abs(direct-formula)<1e-11
  assert abs(direct.real-integral*(a/(2*n))/math.tan(a/(2*n)))<1e-11
  rows.append(dict(nu=nu,n=n,T=direct.real,error=direct.real-integral,complex_discrepancy=abs(direct-formula)))
alias=[]
for n in [8,16,32,33,64]:
 t=sum((math.cos(64*math.pi*k/n)+math.cos(64*math.pi*(k+1)/n))/(2*n) for k in range(n))
 alias.append(dict(n=n,T=t))
# Same finite grids can hide an arbitrary common-multiple frequency.
m=math.lcm(3,5,8)
assert all(m%n==0 for n in [3,5,8])
out=dict(quadratic=quadratic,complex=rows,alias=alias,common_multiple=m)
(w/'corrected_countercheck.json').write_text(json.dumps(out,indent=2))
r=Path('/run/research-drafts/work/tasks/task-445686ad4c874e3385430177c35a17d7/NUMERICAL_CHECK.md');r.parent.mkdir(parents=True,exist_ok=True)
r.write_text('# Fresh corrected-packet countercheck\n\nReproduce with Python standard library: `python3 '+str(w/'corrected_countercheck.py')+'`. [Code]('+str(w/'corrected_countercheck.py')+'), [data]('+str(w/'corrected_countercheck.json')+').\n\nFour exact rational quadratic checks passed. Fifteen independent panelwise complex sums agree with corrected geometric identity and real formula within 1e-11. Frequencies and meshes differ from primary suite. Integer aliasing reproduced. Common multiple 120 hides oscillation on grids 3,5,8 analytically. Tests are observations, not rounding certificates or universal resolution guarantees.\n\n'+json.dumps(out,indent=2))
print('checks passed; maximum discrepancy',max(z['complex_discrepancy'] for z in rows))
