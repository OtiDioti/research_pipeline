# Folder contents

- [primary.md](primary.md) — Logical researcher: primary
