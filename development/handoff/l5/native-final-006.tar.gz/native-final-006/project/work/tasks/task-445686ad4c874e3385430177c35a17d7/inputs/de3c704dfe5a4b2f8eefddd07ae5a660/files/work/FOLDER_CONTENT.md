# Folder contents

- [CONTINUITY.md](CONTINUITY.md) — Scientific continuity
- [PLAN.md](PLAN.md) — Revisable scientific questions, assumptions and methods.
- [PROPOSAL_V3.md](PROPOSAL_V3.md) — Completion proposal after administrative handoff repair
- [check.py](check.py) — py artifact (1671 bytes).
- [data.json](data.json) — json artifact (2395 bytes).
