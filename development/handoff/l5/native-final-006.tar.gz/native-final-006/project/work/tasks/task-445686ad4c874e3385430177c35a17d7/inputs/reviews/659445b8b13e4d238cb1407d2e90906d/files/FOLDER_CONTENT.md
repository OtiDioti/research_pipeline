# Folder contents

- [documents](documents) — Supporting artifacts in documents.
- [work](work) — Scientific plan, derivations, executable scripts and computation data.
