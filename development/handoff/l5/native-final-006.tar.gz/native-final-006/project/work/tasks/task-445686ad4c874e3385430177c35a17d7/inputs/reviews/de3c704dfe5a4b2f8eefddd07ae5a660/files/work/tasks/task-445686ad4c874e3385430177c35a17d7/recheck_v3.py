from fractions import Fraction as F
from pathlib import Path
import json,math
w=Path(__file__).resolve().parent
def T(f,n):
 return (f(F(0))+f(F(1))+2*sum((f(F(k,n)) for k in range(1,n)),F(0)))/(2*n)
rows=[]
for n in [2,5,9,17,37,113]:
 e=T(lambda x:x*x,n)-F(1,3)
 assert e==F(1,6*n*n)
 assert T(lambda x:-x*x,n)+F(1,3)==-e
 assert T(lambda x:x*x,2*n)-F(1,3)==e/4
 rows.append(dict(n=n,error=str(e)))
# Fresh exact smooth stress: sin squared represented by a polynomial is unnecessary;
# x^2(1-x)^2 is invisible on the n=1 grid, integral 1/30.
f=lambda x:x*x*(1-x)**2
assert T(f,1)==0
# Fixed cosine, phase-reduced analytically at dyadic grids; floating independent sum.
cos=[dict(n=n,T=(math.cos(0)/2+sum(math.cos(64*math.pi*k/n) for k in range(1,n))+math.cos(64*math.pi)/2)/n) for n in [8,16,32,33,64,128]]
out=dict(quadratic=rows,polynomial=dict(formula='30*x^2*(1-x)^2',integral='1',T1=str(30*T(f,1)),T2=str(30*T(f,2))),cosine=cos)
(w/'recheck_v3.json').write_text(json.dumps(out,indent=2))
r=Path('/run/research-drafts/work/tasks/task-445686ad4c874e3385430177c35a17d7/NUMERICAL_CHECK.md');r.parent.mkdir(parents=True,exist_ok=True)
r.write_text('# Fresh version-3 numerical countercheck\n\nReproduce with Python standard library: `python3 /project/work/tasks/task-445686ad4c874e3385430177c35a17d7/recheck_v3.py`. [Code](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/recheck_v3.py); [data](/project/work/tasks/task-445686ad4c874e3385430177c35a17d7/recheck_v3.json).\n\nSix exact quadratic/sign/quartering checks passed. Polynomial 30*x^2*(1-x)^2 has exact integral 1 and T1=0. Cosine aliasing reproduced at n=8,16,32. Float residuals are observations, not bounds. Finite tests cannot certify arbitrary smooth functions.\n\n'+json.dumps(out,indent=2))
print(json.dumps(out))
