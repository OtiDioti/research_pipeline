from fractions import Fraction as F
import math, json
from pathlib import Path
rows=[]
for n in [1,2,4,8,16,32,64,128,1024]:
    t=(F(1,2)+sum((F(k,n)**2 for k in range(1,n)),F(0)))/n
    expected=F(1,6*n*n)
    assert t-F(1,3)==expected
    tf=(0.5+math.fsum((k/n)**2 for k in range(1,n)))/n
    rows.append(dict(n=n,exact_T=str(t),exact_error=str(expected),float_T=tf,float_error=tf-1/3,scaled_error=n*n*(tf-1/3)))
stress=[]
m=32
for n in [8,16,32,64,128]:
    t=(0.5*(math.cos(0)+math.cos(2*math.pi*m))+math.fsum(math.cos(2*math.pi*m*k/n) for k in range(1,n)))/n
    stress.append(dict(m=m,n=n,T=t,integral=0,error=t))
result=dict(quadratic=rows,stress=stress)
Path('/project/work/data.json').write_text(json.dumps(result,indent=2)+'\n')
r=Path('/run/research-drafts/work/NUMERICAL_CHECK.md');r.parent.mkdir(parents=True,exist_ok=True)
r.write_text('# Numerical check\n\nRun `python3 /project/work/check.py` with Python 3 standard library. Code: [check.py](/project/work/check.py); data: [data.json](/project/work/data.json).\n\nUniform composite trapezoids for x^2: all nine exact Fraction checks passed for n=1,2,4,8,16,32,64,128,1024 against T-1/3=1/(6n^2). Floating scaled errors follow 1/6, subject to cancellation.\n\nFor fixed smooth f(x)=cos(64*pi*x), exact integral is zero. At n=8,16,32 every sample is exactly 1 in real arithmetic, so T=1; at n=64,128 exact T=0 by cosine cancellation. Floating observations follow below. This is aliasing; it refutes universal accuracy and refinement-based confidence from a few smooth tests, not convergence for a fixed C^2 function.\n\n```json\n'+json.dumps(result,indent=2)+'\n```\n')
print(json.dumps(result,indent=2))
