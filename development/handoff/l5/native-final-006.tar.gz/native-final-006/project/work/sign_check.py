import cmath,math,json
from pathlib import Path
rows=[]
for nu in [0.25,17.125,32.25]:
 for n in [3,16,32,33,64,4096]:
  w=2*math.pi*nu;q=cmath.exp(1j*w/n);end=cmath.exp(1j*w)
  direct=(0.5*(1+end)+sum(cmath.exp(1j*w*k/n) for k in range(1,n)))/n
  correct=(1-end)*(1/(1-q)-0.5)/n
  wrong=-correct
  real=(math.sin(w)/w)*(w/(2*n))/math.tan(w/(2*n))
  delta=abs(direct-correct)
  assert delta<2e-12
  assert abs(direct.real-real)<2e-12
  rows.append(dict(nu=nu,n=n,direct_real=direct.real,direct_imag=direct.imag,correct_real=correct.real,correct_imag=correct.imag,wrong_real=wrong.real,complex_difference=delta))
Path('/project/work/sign_check_data.json').write_text(json.dumps(rows,indent=2)+'\n')
r=Path('/run/research-drafts/work/NUMERICAL_CHECK.md');r.parent.mkdir(parents=True,exist_ok=True)
r.write_text('# Direct complex sign correction check\n\nRun `python3 /project/work/sign_check.py` using Python 3 standard library. [Code](/project/work/sign_check.py), [data](/project/work/sign_check_data.json). Eighteen direct endpoint-weighted complex sums agree with corrected formula (1-exp(i*w))*(1/(1-exp(i*w/n))-1/2)/n and final real formula I*z*cot(z) within 2e-12. The previous leading factor gives the negative. This corroborates the O1 repair; finite tolerances are observations, not rigorous arithmetic bounds. Frequencies 0.25,17.125,32.25 and n=3,16,32,33,64,4096 avoid q=1. Integer singular cases remain handled by the roots-of-unity argument.\n\n```json\n'+json.dumps(rows,indent=2)+'\n```\n')
print('passed',len(rows),'max_difference',max(r['complex_difference'] for r in rows))
