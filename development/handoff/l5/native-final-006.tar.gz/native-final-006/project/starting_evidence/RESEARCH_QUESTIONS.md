# Public integration investigation

1. Derive the signed composite trapezoidal integration error for f(x)=x^2 on
   [0,1], state the sign convention and dependence on subdivision count, and
   corroborate the result computationally.
2. Assess what those computations establish about reliability for other smooth
   functions. Support the scope assessment with an independently checkable stress
   case, counterexample or justified limitation.
