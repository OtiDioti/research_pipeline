# Folder contents

- [.research_pipeline](.research_pipeline) — Private controller status and bounded backend diagnostics.
- [AGENTS.md](AGENTS.md) — Human-owned project instructions (read-only).
- [HUMAN_FEEDBACK.md](HUMAN_FEEDBACK.md) — Distinct human scientific feedback (read-only to agents).
- [RESEARCH_STATUS.md](RESEARCH_STATUS.md) — Operational state and links to current scientific progress.
- [handoffs](handoffs) — Continuation guidance, preserved human edits and proposed reconciliations.
- [outputs](outputs) — Research findings and supporting figures.
- [sources](sources) — Retrieved scientific sources and literature assessment.
- [starting_evidence](starting_evidence) — Human-owned scientific inputs (read-only; questions and supplied evidence).
- [work](work) — Scientific plan, derivations, executable scripts and computation data.

Starting evidence files (read-only):

- [RESEARCH_QUESTIONS.md](starting_evidence/RESEARCH_QUESTIONS.md) — Supplied scientific input.
